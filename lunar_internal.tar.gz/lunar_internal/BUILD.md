# Lunar Internal — Build Instructions

## Prerequisites
- Android NDK r25+ (tested with r26)
- CMake 3.18+
- Target: ARM64-v8a, Android API 26+
- Real ImGui sources (replace stubs in imgui/)

## Step 1: Download Real ImGui
```bash
# Replace the stub files with real ImGui
git clone https://github.com/ocornut/imgui.git /tmp/imgui_real
cp /tmp/imgui_real/imgui.h           imgui/
cp /tmp/imgui_real/imgui.cpp         imgui/
cp /tmp/imgui_real/imgui_draw.cpp    imgui/
cp /tmp/imgui_real/imgui_tables.cpp  imgui/
cp /tmp/imgui_real/imgui_widgets.cpp imgui/
cp /tmp/imgui_real/imgui_internal.h  imgui/
cp /tmp/imgui_real/imconfig.h        imgui/
cp /tmp/imgui_real/imstb_*.h         imgui/
cp /tmp/imgui_real/backends/imgui_impl_opengl3.h    imgui/
cp /tmp/imgui_real/backends/imgui_impl_opengl3.cpp  imgui/
cp /tmp/imgui_real/backends/imgui_impl_android.h    imgui/
cp /tmp/imgui_real/backends/imgui_impl_android.cpp  imgui/
```

## Step 2: Build with NDK
```bash
export NDK=/path/to/android-ndk-r26
export TOOLCHAIN=$NDK/build/cmake/android.toolchain.cmake

mkdir build && cd build

cmake .. \
  -DCMAKE_TOOLCHAIN_FILE=$TOOLCHAIN \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-26 \
  -DCMAKE_BUILD_TYPE=Release

make -j$(nproc)
```

Output:
- `build/liblunar.so` — The injectable library
- `build/lunar_inject` — The injector binary

## Step 3: Push to Device
```bash
adb push build/liblunar.so /data/local/tmp/
adb push build/lunar_inject /data/local/tmp/
adb shell chmod +x /data/local/tmp/lunar_inject
```

## Step 4: Inject
```bash
# Launch the game first, then:
adb shell su -c /data/local/tmp/lunar_inject

# Or with custom paths:
adb shell su -c "/data/local/tmp/lunar_inject /data/local/tmp/liblunar.so com.dts.freefiremax"
```

## Controls
- **3-finger tap**: Toggle menu overlay
- Menu has sections: ESP, Aimbot, Silent Aim, Weapon, Bypass
