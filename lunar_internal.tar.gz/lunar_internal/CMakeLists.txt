cmake_minimum_required(VERSION 3.18)
project(lunar VERSION 1.0.0 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_C_STANDARD 11)

# ARM64 Android
set(ANDROID_ABI arm64-v8a)
set(ANDROID_PLATFORM android-26)

# Build shared library
add_library(lunar SHARED
    src/main.cpp
    src/il2cpp.cpp
    src/hooks.cpp
    src/esp.cpp
    src/aimbot.cpp
    src/norecoil.cpp
    src/bypass.cpp
    src/menu.cpp
    src/injector.cpp
    imgui/imgui.cpp
    imgui/imgui_draw.cpp
    imgui/imgui_tables.cpp
    imgui/imgui_widgets.cpp
    imgui/imgui_impl_opengl3.cpp
    imgui/imgui_impl_android.cpp
)

target_include_directories(lunar PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
    ${CMAKE_CURRENT_SOURCE_DIR}/imgui
    ${CMAKE_CURRENT_SOURCE_DIR}/dobby
)

target_link_libraries(lunar PRIVATE
    log
    android
    EGL
    GLESv3
    dl
)

target_compile_options(lunar PRIVATE
    -fvisibility=hidden
    -ffunction-sections
    -fdata-sections
    -O2
    -DANDROID
    -D__ANDROID__
)

target_link_options(lunar PRIVATE
    -Wl,--gc-sections
    -Wl,--strip-all
    -Wl,-z,max-page-size=16384
)

# Injector standalone binary
add_executable(lunar_inject
    src/inject_main.cpp
    src/injector.cpp
)

target_include_directories(lunar_inject PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/include
)

target_compile_options(lunar_inject PRIVATE -O2 -DANDROID -D__ANDROID__)
target_link_libraries(lunar_inject PRIVATE log dl)
