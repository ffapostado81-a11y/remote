#pragma once
// ============================================================================
//  IL2CPP runtime resolver — resolve classes, methods, fields at runtime
//  via il2cpp exports from libil2cpp.so
// ============================================================================

#include <cstdint>
#include <cstring>
#include <dlfcn.h>
#include <android/log.h>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "Lunar", __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, "Lunar", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "Lunar", __VA_ARGS__)

namespace il2cpp {

// ── typedefs matching il2cpp C API ──────────────────────────────────────────
using Il2CppDomain    = void;
using Il2CppAssembly  = void;
using Il2CppImage     = void;
using Il2CppClass     = void;
using Il2CppMethod    = void;
using Il2CppField     = void;
using Il2CppObject    = void;
using Il2CppString    = void;
using Il2CppArray     = void;
using Il2CppType      = void;

// ── function pointer types ──────────────────────────────────────────────────
typedef Il2CppDomain* (*il2cpp_domain_get_t)();
typedef Il2CppAssembly** (*il2cpp_domain_get_assemblies_t)(Il2CppDomain*, size_t*);
typedef Il2CppImage* (*il2cpp_assembly_get_image_t)(Il2CppAssembly*);
typedef Il2CppClass* (*il2cpp_class_from_name_t)(Il2CppImage*, const char*, const char*);
typedef const Il2CppMethod* (*il2cpp_class_get_method_from_name_t)(Il2CppClass*, const char*, int);
typedef Il2CppField* (*il2cpp_class_get_field_from_name_t)(Il2CppClass*, const char*);
typedef size_t (*il2cpp_field_get_offset_t)(Il2CppField*);
typedef void* (*il2cpp_method_get_pointer_t)(const Il2CppMethod*);
typedef const char* (*il2cpp_image_get_name_t)(Il2CppImage*);
typedef void* (*il2cpp_resolve_icall_t)(const char*);
typedef Il2CppString* (*il2cpp_string_new_t)(const char*);
typedef Il2CppObject* (*il2cpp_runtime_invoke_t)(const Il2CppMethod*, void*, void**, void**);
typedef Il2CppClass* (*il2cpp_object_get_class_t)(Il2CppObject*);
typedef const char* (*il2cpp_class_get_name_t)(Il2CppClass*);

// ── exported function pointers ──────────────────────────────────────────────
inline il2cpp_domain_get_t                  domain_get = nullptr;
inline il2cpp_domain_get_assemblies_t       domain_get_assemblies = nullptr;
inline il2cpp_assembly_get_image_t          assembly_get_image = nullptr;
inline il2cpp_class_from_name_t             class_from_name = nullptr;
inline il2cpp_class_get_method_from_name_t  class_get_method_from_name = nullptr;
inline il2cpp_class_get_field_from_name_t   class_get_field_from_name = nullptr;
inline il2cpp_field_get_offset_t            field_get_offset = nullptr;
inline il2cpp_method_get_pointer_t          method_get_pointer = nullptr;
inline il2cpp_image_get_name_t              image_get_name = nullptr;
inline il2cpp_resolve_icall_t               resolve_icall = nullptr;
inline il2cpp_string_new_t                  string_new = nullptr;
inline il2cpp_runtime_invoke_t              runtime_invoke = nullptr;
inline il2cpp_object_get_class_t            object_get_class = nullptr;
inline il2cpp_class_get_name_t              class_get_name = nullptr;

// ── il2cpp base address ─────────────────────────────────────────────────────
inline uintptr_t base_addr = 0;
inline void*     lib_handle = nullptr;

// ── init ────────────────────────────────────────────────────────────────────
inline bool init() {
    lib_handle = dlopen("libil2cpp.so", RTLD_NOW);
    if (!lib_handle) {
        LOGE("Failed to dlopen libil2cpp.so: %s", dlerror());
        return false;
    }

    // Get base address from /proc/self/maps
    FILE* maps = fopen("/proc/self/maps", "r");
    if (maps) {
        char line[512];
        while (fgets(line, sizeof(line), maps)) {
            if (strstr(line, "libil2cpp.so") && strstr(line, "r-xp")) {
                base_addr = strtoull(line, nullptr, 16);
                break;
            }
        }
        fclose(maps);
    }
    if (!base_addr) {
        LOGE("Failed to find libil2cpp.so base in maps");
        return false;
    }

    #define LOAD_SYM(name) \
        name = (decltype(name))dlsym(lib_handle, "il2cpp_" #name); \
        if (!name) LOGW("Missing il2cpp export: il2cpp_" #name);

    LOAD_SYM(domain_get)
    LOAD_SYM(domain_get_assemblies)
    LOAD_SYM(assembly_get_image)
    LOAD_SYM(class_from_name)
    LOAD_SYM(class_get_method_from_name)
    LOAD_SYM(class_get_field_from_name)
    LOAD_SYM(field_get_offset)
    LOAD_SYM(resolve_icall)
    LOAD_SYM(string_new)
    LOAD_SYM(runtime_invoke)
    LOAD_SYM(object_get_class)
    LOAD_SYM(class_get_name)

    #undef LOAD_SYM

    // method_get_pointer may not exist in all builds
    method_get_pointer = (il2cpp_method_get_pointer_t)
        dlsym(lib_handle, "il2cpp_method_get_pointer");

    // image_get_name
    image_get_name = (il2cpp_image_get_name_t)
        dlsym(lib_handle, "il2cpp_image_get_name");

    if (!domain_get || !class_from_name || !class_get_method_from_name) {
        LOGE("Critical il2cpp exports missing");
        return false;
    }

    LOGI("IL2CPP initialized: base=0x%lx", (unsigned long)base_addr);
    return true;
}

// ── resolve image by DLL name ───────────────────────────────────────────────
inline Il2CppImage* get_image(const char* dll_name) {
    if (!domain_get || !domain_get_assemblies || !assembly_get_image)
        return nullptr;

    Il2CppDomain* domain = domain_get();
    if (!domain) return nullptr;

    size_t count = 0;
    Il2CppAssembly** assemblies = domain_get_assemblies(domain, &count);
    if (!assemblies) return nullptr;

    for (size_t i = 0; i < count; i++) {
        Il2CppImage* img = assembly_get_image(assemblies[i]);
        if (!img) continue;

        if (image_get_name) {
            const char* name = image_get_name(img);
            if (name && strcmp(name, dll_name) == 0)
                return img;
        }
    }
    return nullptr;
}

// ── resolve class ───────────────────────────────────────────────────────────
inline Il2CppClass* get_class(const char* dll, const char* ns, const char* name) {
    Il2CppImage* img = get_image(dll);
    if (!img) return nullptr;
    return class_from_name(img, ns, name);
}

// ── resolve method offset (returns absolute pointer) ────────────────────────
inline uintptr_t get_method_offset(const char* dll, const char* ns,
                                    const char* klass, const char* method,
                                    int arg_count) {
    Il2CppClass* cls = get_class(dll, ns, klass);
    if (!cls) return 0;

    const Il2CppMethod* m = class_get_method_from_name(cls, method, arg_count);
    if (!m) return 0;

    // The method struct has the methodPointer at offset 0 in most il2cpp builds
    uintptr_t ptr = *(uintptr_t*)m;
    if (ptr < 0x100000) return 0;
    return ptr;
}

// ── resolve field offset ────────────────────────────────────────────────────
inline size_t get_field_offset(const char* dll, const char* ns,
                                const char* klass, const char* field_name) {
    Il2CppClass* cls = get_class(dll, ns, klass);
    if (!cls) return 0;

    Il2CppField* f = class_get_field_from_name(cls, field_name);
    if (!f) return 0;

    return field_get_offset(f);
}

// ── get static address from il2cpp base + RVA ───────────────────────────────
inline uintptr_t get_absolute(uintptr_t rva) {
    return base_addr + rva;
}

// ── cleanup ─────────────────────────────────────────────────────────────────
inline void shutdown() {
    // Don't dlclose — hooks may still reference the lib
}

} // namespace il2cpp
