#pragma once
// ============================================================================
//  Unity engine API — wrappers around IL2CPP-resolved methods
//  Resolved once at init, called throughout the cheat
// ============================================================================

#include "il2cpp_api.h"
#include <cmath>

// ── math types ──────────────────────────────────────────────────────────────
struct Vector2 { float x, y; };

struct Vector3 {
    float x, y, z;
    Vector3() : x(0), y(0), z(0) {}
    Vector3(float x, float y, float z) : x(x), y(y), z(z) {}

    Vector3 operator-(const Vector3& o) const { return {x-o.x, y-o.y, z-o.z}; }
    Vector3 operator+(const Vector3& o) const { return {x+o.x, y+o.y, z+o.z}; }
    Vector3 operator*(float s) const { return {x*s, y*s, z*s}; }

    float magnitude() const { return sqrtf(x*x + y*y + z*z); }

    static float Distance(const Vector3& a, const Vector3& b) {
        return (a - b).magnitude();
    }
    static Vector3 Lerp(const Vector3& a, const Vector3& b, float t) {
        return {a.x + (b.x-a.x)*t, a.y + (b.y-a.y)*t, a.z + (b.z-a.z)*t};
    }
    static Vector3 Normalized(const Vector3& v) {
        float m = v.magnitude();
        if (m < 1e-6f) return {0,0,0};
        return {v.x/m, v.y/m, v.z/m};
    }
    static float Angle(const Vector3& a, const Vector3& b) {
        float d = a.x*b.x + a.y*b.y + a.z*b.z;
        float ma = a.magnitude(), mb = b.magnitude();
        if (ma < 1e-6f || mb < 1e-6f) return 180.f;
        float cos_a = d / (ma * mb);
        if (cos_a > 1.f) cos_a = 1.f;
        if (cos_a < -1.f) cos_a = -1.f;
        return acosf(cos_a) * (180.f / 3.14159265f);
    }
    static Vector3 zero() { return {0,0,0}; }
};

struct Quaternion {
    float x, y, z, w;
};

struct Color {
    float r, g, b, a;
};

// ── Unity API function pointers (resolved at init) ──────────────────────────
namespace unity {

// Camera
inline void* (*Camera_main)() = nullptr;
inline Vector3 (*Camera_WorldToScreenPoint)(void* cam, Vector3 pos) = nullptr;

// Transform
inline void* (*Component_GetTransform)(void*) = nullptr;
inline Vector3 (*Transform_GetPosition)(void*) = nullptr;
inline Quaternion (*Transform_GetRotation)(void*) = nullptr;
inline Vector3 (*Transform_GetForward)(void*) = nullptr;

// Screen
inline int (*Screen_get_width)() = nullptr;
inline int (*Screen_get_height)() = nullptr;

// ── Game-specific (COW / Free Fire) ─────────────────────────────────────────
// Match
inline void* (*Curent_Match)() = nullptr;
inline void* (*GetLocalPlayer)(void* match) = nullptr;
inline int   (*get_MatchState)(void* match) = nullptr;

// Player
inline Vector3 (*getPosition)(void* player) = nullptr;
inline Vector3 (*GetHeadPosition)(void* player) = nullptr;
inline Vector3 (*GetHipPosition)(void* player) = nullptr;
inline bool    (*get_isVisible)(void* player) = nullptr;
inline bool    (*get_isLocalTeam)(void* player) = nullptr;
inline bool    (*get_IsDieing)(void* player) = nullptr;
inline bool    (*get_IsFiring)(void* player) = nullptr;
inline bool    (*get_IsSighting)(void* player) = nullptr;
inline float   (*get_MaxHP)(void* player) = nullptr;
inline float   (*get_CurrentHP)(void* player) = nullptr;
inline void*   (*Player_GetHeadCollider)(void* player) = nullptr;
inline void    (*set_aim2)(void* player, Quaternion rot) = nullptr;

// Component
inline void*   (*Component_get_gameObject)(void* comp) = nullptr;

// PlayerCameraManager
inline void* (*GetPlayerCameraManager)(void* playerController) = nullptr;

// ListPlayer offset (from match struct)
inline uintptr_t ListPlayer_offset = 0;
inline uintptr_t m_State_offset    = 0;
inline uintptr_t m_LocalPlayer_offset = 0;

// Screen dimensions cache
inline float screenWidth  = 1920.f;
inline float screenHeight = 1080.f;

// ── Init: resolve all methods ───────────────────────────────────────────────
inline bool init() {
    LOGI("Resolving Unity API methods...");

    // Camera.main
    auto cam_main = il2cpp::get_method_offset(
        "UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "get_main", 0);
    if (cam_main) Camera_main = (decltype(Camera_main))cam_main;

    // Camera.WorldToScreenPoint
    auto w2s = il2cpp::get_method_offset(
        "UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "WorldToScreenPoint", 1);
    if (w2s) Camera_WorldToScreenPoint = (decltype(Camera_WorldToScreenPoint))w2s;

    // Component.get_transform
    auto get_tf = il2cpp::get_method_offset(
        "UnityEngine.CoreModule.dll", "UnityEngine", "Component", "get_transform", 0);
    if (get_tf) Component_GetTransform = (decltype(Component_GetTransform))get_tf;

    // Transform.get_position
    auto tf_pos = il2cpp::get_method_offset(
        "UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "get_position", 0);
    if (tf_pos) Transform_GetPosition = (decltype(Transform_GetPosition))tf_pos;

    // Transform.get_rotation
    auto tf_rot = il2cpp::get_method_offset(
        "UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "get_rotation", 0);
    if (tf_rot) Transform_GetRotation = (decltype(Transform_GetRotation))tf_rot;

    // Transform.get_forward
    auto tf_fwd = il2cpp::get_method_offset(
        "UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "get_forward", 0);
    if (tf_fwd) Transform_GetForward = (decltype(Transform_GetForward))tf_fwd;

    // Screen.width/height
    auto sw = il2cpp::get_method_offset(
        "UnityEngine.CoreModule.dll", "UnityEngine", "Screen", "get_width", 0);
    if (sw) Screen_get_width = (decltype(Screen_get_width))sw;

    auto sh = il2cpp::get_method_offset(
        "UnityEngine.CoreModule.dll", "UnityEngine", "Screen", "get_height", 0);
    if (sh) Screen_get_height = (decltype(Screen_get_height))sh;

    // Component.get_gameObject
    auto go = il2cpp::get_method_offset(
        "UnityEngine.CoreModule.dll", "UnityEngine", "Component", "get_gameObject", 0);
    if (go) Component_get_gameObject = (decltype(Component_get_gameObject))go;

    // ── Game-specific methods (COW namespace, obfuscated names) ─────────────
    // These use the original obfuscated names from the OB54 dump

    // Curent_Match (singleton getter)
    auto cmatch = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "FDAEPHMIEPC", "get_Instance", 0);
    if (!cmatch) cmatch = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "MatchGameBase", "get_Instance", 0);
    if (cmatch) Curent_Match = (decltype(Curent_Match))cmatch;

    // GetLocalPlayer
    auto glp = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "MatchGameBase", "GetLocalPlayer", 0);
    if (glp) GetLocalPlayer = (decltype(GetLocalPlayer))glp;

    // Player methods
    auto gpos = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "Player", "getPosition", 0);
    if (gpos) getPosition = (decltype(getPosition))gpos;

    auto ghp = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "Player", "GetHeadPosition", 0);
    if (ghp) GetHeadPosition = (decltype(GetHeadPosition))ghp;

    auto ghip = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "Player", "GetHipPosition", 0);
    if (ghip) GetHipPosition = (decltype(GetHipPosition))ghip;

    auto gvis = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "Player", "get_isVisible", 0);
    if (gvis) get_isVisible = (decltype(get_isVisible))gvis;

    auto gteam = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "Player", "get_isLocalTeam", 0);
    if (gteam) get_isLocalTeam = (decltype(get_isLocalTeam))gteam;

    auto gdie = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "Player", "get_IsDieing", 0);
    if (gdie) get_IsDieing = (decltype(get_IsDieing))gdie;

    auto gfire = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "Player", "get_IsFiring", 0);
    if (gfire) get_IsFiring = (decltype(get_IsFiring))gfire;

    auto gsight = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "Player", "get_IsSighting", 0);
    if (gsight) get_IsSighting = (decltype(get_IsSighting))gsight;

    auto gmhp = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "Player", "get_MaxHP", 0);
    if (gmhp) get_MaxHP = (decltype(get_MaxHP))gmhp;

    auto gchp = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "Player", "get_CurrentHP", 0);
    if (gchp) get_CurrentHP = (decltype(get_CurrentHP))gchp;

    auto ghc = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "Player", "get_HeadCollider", 0);
    if (ghc) Player_GetHeadCollider = (decltype(Player_GetHeadCollider))ghc;

    auto sa2 = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay", "Player", "set_aim2", 1);
    if (sa2) set_aim2 = (decltype(set_aim2))sa2;

    // Update screen dimensions
    if (Screen_get_width && Screen_get_height) {
        screenWidth  = (float)Screen_get_width();
        screenHeight = (float)Screen_get_height();
    }

    LOGI("Unity API resolved: Camera=%p, W2S=%p, Match=%p, LocalPlayer=%p",
         (void*)Camera_main, (void*)Camera_WorldToScreenPoint,
         (void*)Curent_Match, (void*)GetLocalPlayer);

    return Camera_main && Camera_WorldToScreenPoint && Component_GetTransform;
}

// ── Helper: WorldToScreen with Y flip ───────────────────────────────────────
inline bool WorldToScreen(Vector3 world, Vector2& out) {
    if (!Camera_main || !Camera_WorldToScreenPoint) return false;
    void* cam = Camera_main();
    if (!cam) return false;

    Vector3 s = Camera_WorldToScreenPoint(cam, world);
    if (s.z < 1.f) return false;

    out.x = s.x;
    out.y = screenHeight - s.y;  // Unity Y is bottom-up, OpenGL is top-down
    return true;
}

// ── Player dictionary iteration helper ──────────────────────────────────────
struct DictEntry {
    int32_t hashCode;
    int32_t next;
    void*   key;
    void*   value;
};

struct PlayerDict {
    void*      klass;
    void*      monitor;
    void*      buckets;
    DictEntry* entries;
    int32_t    count;
    // ... more fields
};

inline PlayerDict* GetPlayerList(void* match) {
    if (!match) return nullptr;
    // The ListPlayer offset varies — use the one from the dump
    // It's typically at a known offset in MatchGameBase
    // For OB54, this is resolved dynamically via field offset
    static uintptr_t list_off = 0;
    if (!list_off) {
        list_off = il2cpp::get_field_offset(
            "Assembly-CSharp.dll", "COW.GamePlay",
            "MatchGameBase", "m_Players");
        if (!list_off) list_off = 0x90; // fallback OB54
    }
    return *(PlayerDict**)((uintptr_t)match + list_off);
}

} // namespace unity
