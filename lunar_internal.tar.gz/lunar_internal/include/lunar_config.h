#pragma once
// ============================================================================
//  LUNAR INTERNAL — Config central
//  OB54 build — Free Fire MAX (com.dts.freefiremax)
//  Unity IL2CPP ARM64-v8a
// ============================================================================

#include <cstdint>
#include <cmath>
#include <atomic>
#include <android/log.h>
#include <sys/mman.h>
#include <pthread.h>
#include <sys/prctl.h>

#define LTAG "Lunar"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LTAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LTAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LTAG, __VA_ARGS__)

namespace lunar {

inline const char* build_tag    = "OB54";
inline const char* game_pkg     = "com.dts.freefiremax";
inline const char* il2cpp_lib   = "libil2cpp.so";
inline const char* unity_lib    = "libunity.so";

// ── Bone IDs ────────────────────────────────────────────────────────────────
enum BoneId : int {
    kHead  = 0,
    kNeck  = 1,
    kChest = 2,
    kHip   = 3,
    kSmart = 4   // chest até N tiros, depois head
};

// ── Feature toggles (menu binds) ────────────────────────────────────────────
// Field names match what src/*.cpp use: g_cfg.esp, g_cfg.aim_mode, etc.
struct Config {
    // ESP
    std::atomic<bool>  esp{true};
    std::atomic<bool>  esp_box{true};
    std::atomic<bool>  esp_hp{true};
    std::atomic<bool>  esp_dist{true};
    std::atomic<bool>  esp_snap{true};
    std::atomic<bool>  esp_skeleton{false};
    std::atomic<float> esp_max_dist{300.f};

    // Aimbot
    std::atomic<int>   aim_mode{0};         // 0=off, 1=legit, 2=rage
    std::atomic<int>   aim_bone{kHead};
    std::atomic<float> aim_fov{120.f};
    std::atomic<float> aim_smooth{5.f};
    std::atomic<bool>  aim_visible_only{true};
    std::atomic<bool>  aim_sticky{true};
    std::atomic<int>   chest_first_n{2};
    std::atomic<float> head_switch_delay{0.12f};

    // Silent aim (OnCalcDamage hook)
    std::atomic<bool>  silent_aim{false};
    std::atomic<float> silent_fov{180.f};
    std::atomic<int>   silent_bone{kHead};
    std::atomic<int>   silent_chest_n{2};

    // NoRecoil / NoSpread / RapidFire
    std::atomic<bool>  norecoil{false};
    std::atomic<bool>  nospread{false};
    std::atomic<bool>  rapidfire{false};
    std::atomic<int>   recoil_mode{1};      // 0=zero, 1=stealth, 2=off
    std::atomic<float> recoil_scale{0.06f};
    std::atomic<float> spread_scale{0.08f};

    // Speedhack
    std::atomic<bool>  speedhack{false};
    std::atomic<float> speed_scale{1.5f};

    // Bypass
    std::atomic<bool>  bypass{true};
    std::atomic<int>   ac_repatch_base_ms{90};
};

inline Config g_cfg;

// ── Offsets OB54 (statics resolvidos por il2cpp base) ───────────────────────
namespace off {
    inline constexpr uintptr_t ac_facade      = 0xB024AD8;
    inline constexpr uintptr_t speed_facade   = 0xB023498;
    inline constexpr uintptr_t ac_fields      = 0xB8;
    inline constexpr uintptr_t ac_flag        = 0x20;
    inline constexpr uintptr_t player_collider = 0x78;
}

// ── Silent AIM defaults ─────────────────────────────────────────────────────
namespace silent {
    inline constexpr int   default_bone        = kHead;
    inline constexpr int   default_chest_shots = 2;
    inline constexpr float neck_lerp           = 0.12f;
    inline constexpr float chest_lerp          = 0.34f;
    inline constexpr float target_cache_s      = 0.11f;
    inline constexpr float smart_reset_s       = 3.0f;
}

// ── Aimbot defaults ─────────────────────────────────────────────────────────
namespace aim {
    inline constexpr int   default_chest_shots = 2;
    inline constexpr float head_delay_ms       = 120.f;
    inline constexpr float shot_reset_s        = 2.5f;
    inline constexpr float chest_lerp          = 0.34f;
    inline constexpr float sticky_fov_mul      = 1.15f;
}

// ── Bypass defaults ─────────────────────────────────────────────────────────
namespace bypass {
    inline constexpr float recoil_scale   = 0.06f;
    inline constexpr float spread_scale   = 0.08f;
    inline constexpr int   ac_repatch_base_ms = 90;
}

// ── Helpers ─────────────────────────────────────────────────────────────────
inline float clampf(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}
inline int clampi(int v, int lo, int hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

} // namespace lunar
