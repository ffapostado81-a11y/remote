#pragma once
// ============================================================================
//  Dobby hook wrapper — thin inline-hooking API
//  On Android ARM64, Dobby is the standard for inline hooks.
//  This header provides both: link against libdobby.a if available,
//  or fallback to a minimal trampoline implementation.
// ============================================================================

#include <cstdint>
#include <cstring>
#include <sys/mman.h>
#include <unistd.h>
#include <android/log.h>

// Try to use Dobby if linked
extern "C" {
    int DobbyHook(void* address, void* replace_func, void** origin_func) __attribute__((weak));
    int DobbyDestroy(void* address) __attribute__((weak));
}

namespace hooks {

// ── Minimal inline hook fallback (ARM64) ────────────────────────────────────
// If Dobby is not linked, this provides basic hook capability
// using branch instructions + trampoline allocation

inline void* alloc_exec(size_t sz) {
    void* p = mmap(nullptr, sz, PROT_READ | PROT_WRITE | PROT_EXEC,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    return (p == MAP_FAILED) ? nullptr : p;
}

inline bool make_writable(void* addr, size_t len) {
    uintptr_t page = (uintptr_t)addr & ~(uintptr_t)(sysconf(_SC_PAGESIZE) - 1);
    size_t page_sz = sysconf(_SC_PAGESIZE);
    size_t total = ((uintptr_t)addr + len) - page + page_sz - 1;
    total = total & ~(page_sz - 1);
    return mprotect((void*)page, total, PROT_READ | PROT_WRITE | PROT_EXEC) == 0;
}

// ARM64: LDR X17, [PC, #8]; BR X17; <64-bit addr>
inline bool install_hook(void* target, void* hook_fn, void** orig_out) {
    // Prefer Dobby if available
    if (DobbyHook) {
        return DobbyHook(target, hook_fn, orig_out) == 0;
    }

    // Fallback: manual trampoline
    // Save original bytes (16 bytes = 4 instructions minimum)
    constexpr size_t kPatchSize = 16;
    constexpr size_t kTrampolineSize = 48;

    uint8_t* trampoline = (uint8_t*)alloc_exec(kTrampolineSize);
    if (!trampoline) return false;

    // Copy original bytes to trampoline
    memcpy(trampoline, target, kPatchSize);

    // Add jump back to target + kPatchSize
    // LDR X17, [PC, #8]; BR X17; <addr>
    uint32_t* jmp_back = (uint32_t*)(trampoline + kPatchSize);
    jmp_back[0] = 0x58000051; // LDR X17, [PC, #8]
    jmp_back[1] = 0xD61F0220; // BR X17
    *(uint64_t*)(jmp_back + 2) = (uint64_t)target + kPatchSize;

    *orig_out = trampoline;

    // Patch target: LDR X17, [PC, #8]; BR X17; <hook_fn>
    if (!make_writable(target, kPatchSize)) return false;

    uint32_t* patch = (uint32_t*)target;
    patch[0] = 0x58000051; // LDR X17, [PC, #8]
    patch[1] = 0xD61F0220; // BR X17
    *(uint64_t*)(patch + 2) = (uint64_t)hook_fn;

    // Flush instruction cache
    __builtin___clear_cache((char*)target, (char*)target + kPatchSize);
    __builtin___clear_cache((char*)trampoline, (char*)trampoline + kTrampolineSize);

    return true;
}

inline bool remove_hook(void* target) {
    if (DobbyDestroy) {
        return DobbyDestroy(target) == 0;
    }
    // Manual: would need saved bytes — for now, hooks are permanent
    return false;
}

} // namespace hooks
