// IL2CPP init implementation
#include "il2cpp_api.h"
#include "unity_api.h"

namespace lunar_init {

bool init_il2cpp() {
    if (!il2cpp::init()) return false;
    if (!unity::init()) return false;
    return true;
}

} // namespace lunar_init
