// ============================================================================
//  HOOKS — eglSwapBuffers (ESP rendering) + OnCalcDamage (Silent Aim)
// ============================================================================

#include "lunar_config.h"
#include "il2cpp_api.h"
#include "unity_api.h"
#include "dobby_hook.h"

#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <dlfcn.h>
#include <pthread.h>
#include <sys/prctl.h>

// Forward declarations
namespace lunar_esp  { void render(int w, int h); void init_gl(); bool gl_ready(); }
namespace lunar_menu { void render(int w, int h); void init_gl(); }

// ── eglSwapBuffers hook ─────────────────────────────────────────────────────
static EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay, EGLSurface) = nullptr;
static bool g_gl_initialized = false;
static int g_frame_count = 0;

EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    if (!g_gl_initialized) {
        lunar_esp::init_gl();
        lunar_menu::init_gl();
        g_gl_initialized = true;
    }

    // Get surface dimensions
    EGLint width = 0, height = 0;
    eglQuerySurface(dpy, surface, EGL_WIDTH, &width);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &height);

    if (width > 0 && height > 0) {
        unity::screenWidth  = (float)width;
        unity::screenHeight = (float)height;
    }

    // Render ESP overlay
    if (lunar::g_cfg.esp_enabled.load() && lunar_esp::gl_ready()) {
        lunar_esp::render(width, height);
    }

    // Render menu
    if (lunar::g_cfg.menu_visible.load()) {
        lunar_menu::render(width, height);
    }

    g_frame_count++;
    return orig_eglSwapBuffers(dpy, surface);
}

// ── OnCalcDamage hook (Silent Aim) ──────────────────────────────────────────
static void (*orig_OnCalcDamage)(void* weapon, void* hitInfo) = nullptr;
static thread_local bool g_inDamageHook = false;

// Target cache
static void*  g_silentTarget = nullptr;
static double g_silentCacheTs = 0.0;
static int    g_silentShots = 0;
static void*  g_silentLastTarget = nullptr;
static double g_silentLastHit = 0.0;

static double now_seconds() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

static void* get_closest_enemy_silent() {
    if (!unity::Curent_Match || !unity::GetLocalPlayer || !unity::Camera_main)
        return nullptr;

    void* match = unity::Curent_Match();
    if (!match) return nullptr;

    void* local = unity::GetLocalPlayer(match);
    if (!local) return nullptr;

    void* cam = unity::Camera_main();
    if (!cam) return nullptr;

    Vector3 myPos = unity::getPosition(local);
    Vector3 camFwd = {0, 0, 1};
    if (unity::Component_GetTransform && unity::Transform_GetForward) {
        void* camTf = unity::Component_GetTransform(cam);
        if (camTf) camFwd = unity::Transform_GetForward(camTf);
    }

    unity::PlayerDict* dict = unity::GetPlayerList(match);
    if (!dict || !dict->entries || dict->count <= 0 || dict->count > 512)
        return nullptr;

    float minAngle = 9999.f;
    void* best = nullptr;

    for (int i = 0; i < dict->count; i++) {
        void* enemy = dict->entries[i].value;
        if (!enemy || enemy == local) continue;
        if (unity::get_isLocalTeam && unity::get_isLocalTeam(enemy)) continue;
        if (unity::get_IsDieing && unity::get_IsDieing(enemy)) continue;
        if (unity::get_MaxHP && unity::get_MaxHP(enemy) <= 0) continue;

        Vector3 ePos = unity::getPosition(enemy);
        float dist = Vector3::Distance(myPos, ePos);
        if (dist > 1000.f) continue;

        if (unity::Camera_WorldToScreenPoint) {
            Vector3 s = unity::Camera_WorldToScreenPoint(cam, ePos);
            if (s.z < 1.f) continue;
        }

        if (unity::get_isVisible && !unity::get_isVisible(enemy)) continue;

        Vector3 dir = Vector3::Normalized(ePos - myPos);
        float angle = Vector3::Angle(dir, camFwd) * 100.f;
        if (angle < minAngle) {
            minAngle = angle;
            best = enemy;
        }
    }
    return best;
}

static void* get_target_cached() {
    double now = now_seconds();
    if (g_silentTarget && (now - g_silentCacheTs) < lunar::silent::target_cache_s)
        return g_silentTarget;
    g_silentTarget = get_closest_enemy_silent();
    g_silentCacheTs = now;
    return g_silentTarget;
}

static int resolve_silent_bone(void* target) {
    int bone = lunar::g_cfg.silent_bone.load();
    if (bone != lunar::kSmart) return bone;

    double now = now_seconds();
    if (target != g_silentLastTarget ||
        (now - g_silentLastHit) > lunar::silent::smart_reset_s) {
        g_silentLastTarget = target;
        g_silentShots = 0;
    }
    g_silentLastHit = now;

    int cap = lunar::clampi(lunar::g_cfg.silent_chest_shots.load(), 0,
                            lunar::silent::max_chest_shots);
    if (g_silentShots < cap) {
        g_silentShots++;
        return lunar::kChest;
    }
    return lunar::kHead;
}

struct SilentHit {
    void*   collider;
    void*   gameObj;
    Vector3 pos;
    int     group;
};

static bool resolve_silent_hit(void* target, int bone, SilentHit& out) {
    out = {};
    if (!target || !unity::GetHeadPosition) return false;

    Vector3 head = unity::GetHeadPosition(target);
    Vector3 hip  = unity::GetHipPosition ? unity::GetHipPosition(target) : head;
    void* headCol = unity::Player_GetHeadCollider ?
                    unity::Player_GetHeadCollider(target) : nullptr;

    if (bone == lunar::kHead) {
        out.pos = head;
        out.collider = headCol;
        out.group = lunar::silent::hitgroup_head;
    } else if (bone == lunar::kNeck) {
        out.pos = Vector3::Lerp(head, hip, lunar::silent::neck_lerp);
        out.collider = headCol; // fallback
        out.group = lunar::silent::hitgroup_neck;
    } else {
        out.pos = Vector3::Lerp(head, hip, lunar::silent::chest_lerp);
        out.collider = headCol; // fallback
        out.group = lunar::silent::hitgroup_chest;
    }

    if (!out.collider) return false;
    if (unity::Component_get_gameObject)
        out.gameObj = unity::Component_get_gameObject(out.collider);
    return out.gameObj != nullptr;
}

// ── HitInfo field offsets (resolved at init) ────────────────────────────────
static uintptr_t off_HitObject     = 0;
static uintptr_t off_HitCollider   = 0;
static uintptr_t off_HitGroup      = 0;
static uintptr_t off_HitLocation   = 0;
static uintptr_t off_HitNormal     = 0;
static uintptr_t off_RayDir        = 0;
static uintptr_t off_IgnoreHappens = 0;
static uintptr_t off_ViewBlocked   = 0;
static uintptr_t off_SpecialHit    = 0;

static void resolve_hitinfo_offsets() {
    const char* dll = "Assembly-CSharp.dll";
    const char* ns  = "COW.GamePlay";
    const char* cls = "GMPGMPFNMFP"; // HitObjectInfo (OB54 obfuscated)

    off_HitObject     = il2cpp::get_field_offset(dll, ns, cls, "HLIJMDODPIM");
    off_HitCollider   = il2cpp::get_field_offset(dll, ns, cls, "OCEBCHENIOK");
    off_HitGroup      = il2cpp::get_field_offset(dll, ns, cls, "FLCLOHCBJEI");
    off_HitLocation   = il2cpp::get_field_offset(dll, ns, cls, "MBGBCLNJOMK");
    off_HitNormal     = il2cpp::get_field_offset(dll, ns, cls, "DGFLGBEOGPG");
    off_RayDir        = il2cpp::get_field_offset(dll, ns, cls, "IKDEGKIICJP");
    off_IgnoreHappens = il2cpp::get_field_offset(dll, ns, cls, "DEDOKPCAHAC");
    off_ViewBlocked   = il2cpp::get_field_offset(dll, ns, cls, "GGJOADOBLID");
    off_SpecialHit    = il2cpp::get_field_offset(dll, ns, cls, "LNOIFBAFGOK");

    LOGI("HitInfo offsets: Obj=%zu Col=%zu Grp=%zu Loc=%zu",
         off_HitObject, off_HitCollider, off_HitGroup, off_HitLocation);
}

void hook_OnCalcDamage(void* weapon, void* hitInfo) {
    if (!orig_OnCalcDamage) return;

    if (g_inDamageHook) {
        orig_OnCalcDamage(weapon, hitInfo);
        return;
    }

    if (!lunar::g_cfg.silent_enabled.load() || !weapon || !hitInfo) {
        orig_OnCalcDamage(weapon, hitInfo);
        return;
    }

    g_inDamageHook = true;

    do {
        void* target = get_target_cached();
        if (!target) break;

        if (unity::get_isLocalTeam && unity::get_isLocalTeam(target)) break;
        if (unity::get_IsDieing && unity::get_IsDieing(target)) break;

        SilentHit hit;
        if (!resolve_silent_hit(target, resolve_silent_bone(target), hit)) break;

        void* local = nullptr;
        if (unity::Curent_Match && unity::GetLocalPlayer) {
            void* match = unity::Curent_Match();
            if (match) local = unity::GetLocalPlayer(match);
        }
        if (!local) break;

        Vector3 myPos = unity::getPosition(local);
        Vector3 dir = Vector3::Normalized(hit.pos - myPos);

        if (off_HitObject)     *(void**)((uintptr_t)hitInfo + off_HitObject) = hit.gameObj;
        if (off_HitCollider)   *(void**)((uintptr_t)hitInfo + off_HitCollider) = hit.collider;
        if (off_HitGroup)      *(int*)((uintptr_t)hitInfo + off_HitGroup) = hit.group;
        if (off_HitLocation)   *(Vector3*)((uintptr_t)hitInfo + off_HitLocation) = hit.pos;
        if (off_HitNormal)     *(Vector3*)((uintptr_t)hitInfo + off_HitNormal) = dir;
        if (off_RayDir)        *(Vector3*)((uintptr_t)hitInfo + off_RayDir) = dir;
        if (off_IgnoreHappens) *(bool*)((uintptr_t)hitInfo + off_IgnoreHappens) = false;
        if (off_ViewBlocked)   *(bool*)((uintptr_t)hitInfo + off_ViewBlocked) = false;
        if (off_SpecialHit)    *(uint8_t*)((uintptr_t)hitInfo + off_SpecialHit) = 0;
    } while (false);

    orig_OnCalcDamage(weapon, hitInfo);
    g_inDamageHook = false;
}

// ── Install all hooks ───────────────────────────────────────────────────────
namespace lunar_hooks {

bool installed = false;

bool install() {
    if (installed) return true;

    // Hook eglSwapBuffers for rendering
    void* egl_handle = dlopen("libEGL.so", RTLD_NOW);
    if (!egl_handle) {
        LOGE("Failed to open libEGL.so");
        return false;
    }

    void* swap_addr = dlsym(egl_handle, "eglSwapBuffers");
    if (!swap_addr) {
        LOGE("Failed to find eglSwapBuffers");
        return false;
    }

    if (!hooks::install_hook(swap_addr, (void*)hook_eglSwapBuffers,
                             (void**)&orig_eglSwapBuffers)) {
        LOGE("Failed to hook eglSwapBuffers");
        return false;
    }
    LOGI("eglSwapBuffers hooked at %p", swap_addr);

    // Hook OnCalcDamage for silent aim
    resolve_hitinfo_offsets();

    uintptr_t dmg_addr = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay",
        "FDAEPHMIEPC", "KOODEKEKFEK", 1);

    if (dmg_addr) {
        if (hooks::install_hook((void*)dmg_addr, (void*)hook_OnCalcDamage,
                                (void**)&orig_OnCalcDamage)) {
            LOGI("OnCalcDamage hooked at 0x%lx", (unsigned long)dmg_addr);
        } else {
            LOGW("Failed to hook OnCalcDamage — silent aim unavailable");
        }
    } else {
        LOGW("OnCalcDamage not found — silent aim unavailable");
    }

    installed = true;
    return true;
}

} // namespace lunar_hooks
