// ============================================================================
//  LUNAR INJECTOR — Standalone executable
//  Usage: ./lunar_inject [/path/to/lunar.so] [package_name]
//  Defaults: /data/local/tmp/liblunar.so → com.dts.freefiremax
//  Requires: root (su) or debuggable app
// ============================================================================

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>

namespace lunar_inject {
    pid_t find_pid(const char* pkg);
    bool  inject(pid_t pid, const char* lib_path);
}

static const char* DEFAULT_LIB = "/data/local/tmp/liblunar.so";
static const char* DEFAULT_PKG = "com.dts.freefiremax";

int main(int argc, char* argv[]) {
    const char* lib_path = (argc > 1) ? argv[1] : DEFAULT_LIB;
    const char* pkg_name = (argc > 2) ? argv[2] : DEFAULT_PKG;

    printf("=== LUNAR INJECTOR ===\n");
    printf("Library : %s\n", lib_path);
    printf("Package : %s\n", pkg_name);

    // Check lib exists
    if (access(lib_path, F_OK) != 0) {
        fprintf(stderr, "ERROR: %s not found!\n", lib_path);
        fprintf(stderr, "Push it first: adb push liblunar.so /data/local/tmp/\n");
        return 1;
    }

    // Find game PID
    printf("Looking for %s...\n", pkg_name);
    pid_t pid = -1;

    for (int attempt = 0; attempt < 30; attempt++) {
        pid = lunar_inject::find_pid(pkg_name);
        if (pid > 0) break;

        if (attempt == 0)
            printf("Game not running — waiting (launch it now)...\n");

        usleep(1000 * 1000);
    }

    if (pid <= 0) {
        fprintf(stderr, "ERROR: Could not find %s after 30s\n", pkg_name);
        return 1;
    }

    printf("Found PID: %d\n", pid);

    // Small delay to let game initialize
    printf("Waiting 3s for game to init...\n");
    sleep(3);

    // Inject
    if (lunar_inject::inject(pid, lib_path)) {
        printf("=== INJECTION SUCCESS ===\n");
        printf("lunar.so loaded into %s (PID %d)\n", pkg_name, pid);
        printf("3-finger tap in game to open menu\n");
        return 0;
    } else {
        fprintf(stderr, "=== INJECTION FAILED ===\n");
        fprintf(stderr, "Make sure you have root access (run via su)\n");
        return 1;
    }
}
