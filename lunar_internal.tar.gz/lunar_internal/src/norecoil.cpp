// ============================================================================
//  NORECOIL / NOSPREAD / RAPIDFIRE
//  Internal memory manipulation of weapon context
//  CRITICAL: spread uses C+0x3C NOT C+0x38 (0x38 is "am" — zeroing crashes wctx)
// ============================================================================

#include "lunar_config.h"
#include "il2cpp_api.h"
#include <cstring>
#include <cmath>
#include <cstdint>

namespace lunar_norecoil {

// ── Memory helpers (direct internal access) ─────────────────────────────────
template<typename T>
static T read(uintptr_t addr) {
    if (addr < 0x100000) return T{};
    return *(T*)addr;
}

template<typename T>
static void write(uintptr_t addr, T val) {
    if (addr < 0x100000) return;
    *(T*)addr = val;
}

static bool ok_ptr(uintptr_t p) {
    return p > 0x100000 && p < 0x7FFFFFFFFFFF;
}

// ── Weapon context chain ────────────────────────────────────────────────────
// This resolves through the component system to get the weapon context
// The exact chain depends on the game's component layout

// NRK component resolver — resolve via IL2CPP at init
static uintptr_t (*resolve_nrk)(uintptr_t entity) = nullptr;

struct WeaponSnapshot {
    uintptr_t cky    = 0;    // weapon fire rate struct
    uintptr_t rp     = 0;    // recoil pattern struct
    uintptr_t ctx    = 0;    // weapon context (C)
    float     oh     = 0.f;  // original horizontal recoil
    float     ov     = 0.f;  // original vertical recoil
    float     rm0    = 0.f;  // C+0x40 original (recoil multiplier)
    float     sp0    = 0.f;  // C+0x3C original (spread)
    float     pat[7] = {};   // original recoil pattern (7 floats at C+0x68)
    int16_t   orate  = 0;    // original fire rate
    bool      valid  = false;
};

static WeaponSnapshot g_snaps[8];
static int g_snap_count = 0;

// ── Weapon context validation ───────────────────────────────────────────────
// am at C+0x38 must be in (0,4) — this validates the context is alive
// rm at C+0x40 must be in [0,4)
static uintptr_t get_wctx(uintptr_t entity) {
    if (!resolve_nrk) return 0;
    uintptr_t nk = resolve_nrk(entity);
    if (!ok_ptr(nk)) return 0;

    uintptr_t C = nk + 0x30;
    float am = read<float>(C + 0x38);
    float rm = read<float>(C + 0x40);

    // am validates the context — NEVER write to 0x38
    if (!(am > 0.f && am < 4.f) || !(rm >= 0.f && rm < 4.f))
        return 0;

    return C;
}

// ── Snapshot management ─────────────────────────────────────────────────────
static WeaponSnapshot* get_snapshot(uintptr_t entity, bool create) {
    uintptr_t C = get_wctx(entity);
    if (!C) return nullptr;

    uintptr_t w = read<uintptr_t>(C + 0x48);
    if (!ok_ptr(w)) return nullptr;

    uintptr_t cky = read<uintptr_t>(w + 0x60);
    if (!ok_ptr(cky)) return nullptr;

    // Find existing
    for (int i = 0; i < g_snap_count; i++)
        if (g_snaps[i].cky == cky) return &g_snaps[i];

    if (!create) return nullptr;

    uintptr_t rp = read<uintptr_t>(cky + 0x68);
    if (!ok_ptr(rp)) return nullptr;

    float h = read<float>(rp + 0x1C);
    float v = read<float>(rp + 0x20);
    if (!(h == h) || !(v == v) || h < 0.f || h > 60.f || v < 0.f || v > 60.f)
        return nullptr;

    // Evict oldest if full
    if (g_snap_count >= 8) {
        memmove(&g_snaps[0], &g_snaps[1], sizeof(WeaponSnapshot) * 7);
        g_snap_count--;
    }

    WeaponSnapshot* s = &g_snaps[g_snap_count++];
    s->cky   = cky;
    s->rp    = rp;
    s->ctx   = C;
    s->oh    = h;
    s->ov    = v;
    s->orate = read<int16_t>(cky + 0x4C);
    s->rm0   = read<float>(C + 0x40);
    s->sp0   = read<float>(C + 0x3C);

    for (int i = 0; i < 7; i++)
        s->pat[i] = read<float>(C + 0x68 + (uintptr_t)i * 4);

    s->valid = true;
    return s;
}

// ── Restore original values ─────────────────────────────────────────────────
static void restore_all() {
    for (int i = 0; i < g_snap_count; i++) {
        WeaponSnapshot& s = g_snaps[i];

        if (ok_ptr(s.rp)) {
            write<float>(s.rp + 0x1C, s.oh);
            write<float>(s.rp + 0x20, s.ov);
        }
        if (ok_ptr(s.cky) && s.orate > 0)
            write<int16_t>(s.cky + 0x4C, s.orate);

        if (s.valid && ok_ptr(s.ctx)) {
            for (int k = 0; k < 7; k++)
                write<float>(s.ctx + 0x68 + (uintptr_t)k * 4, s.pat[k]);
            write<float>(s.ctx + 0x40, s.rm0);
            write<float>(s.ctx + 0x3C, s.sp0);  // spread at 0x3C, NOT 0x38
        }
    }
    g_snap_count = 0;
}

// ── Apply recoil modification ───────────────────────────────────────────────
static void apply_recoil(uintptr_t C, WeaponSnapshot* s, float scale) {
    if (!s || !ok_ptr(C) || !s->valid) return;
    float k = lunar::clampf(scale, 0.f, 1.f);

    if (k <= 0.f) {
        // Full zero
        float z[7] = {};
        memcpy((void*)(C + 0x68), z, sizeof(z));
        write<float>(C + 0x40, 0.f);
        if (ok_ptr(s->rp)) {
            write<float>(s->rp + 0x1C, 0.f);
            write<float>(s->rp + 0x20, 0.f);
        }
    } else {
        // Stealth: residual at scale%
        for (int i = 0; i < 7; i++)
            write<float>(C + 0x68 + (uintptr_t)i * 4, s->pat[i] * k);
        write<float>(C + 0x40, s->rm0 * k);
        if (ok_ptr(s->rp)) {
            write<float>(s->rp + 0x1C, s->oh * k);
            write<float>(s->rp + 0x20, s->ov * k);
        }
    }
}

static void apply_spread(uintptr_t C, WeaponSnapshot* s, float scale) {
    if (!s || !ok_ptr(C) || !s->valid) return;
    float k = lunar::clampf(scale, 0.f, 1.f);
    // CRITICAL: 0x3C for spread, NEVER 0x38 (am field — crashes wctx validation)
    write<float>(C + 0x3C, s->sp0 * k);
}

static void apply_rapidfire(WeaponSnapshot* s) {
    if (!s || !ok_ptr(s->cky)) return;
    if (s->orate > 50 && s->orate < 2000) {
        int32_t want = (int32_t)s->orate * 3 / 2;
        if (want > 3000) want = 3000;
        int16_t cur = read<int16_t>(s->cky + 0x4C);
        if (cur != (int16_t)want)
            write<int16_t>(s->cky + 0x4C, (int16_t)want);
    }
}

// ── Main tick ───────────────────────────────────────────────────────────────
static bool last_recoil  = false;
static bool last_spread  = false;
static bool last_rapid   = false;
static bool last_any     = false;

void tick(uintptr_t local_entity) {
    bool nr = lunar::g_cfg.norecoil.load();
    bool ns = lunar::g_cfg.nospread.load();
    bool rf = lunar::g_cfg.rapidfire.load();
    bool any = nr || ns || rf;

    // Clean transition: restore on disable
    if (last_any && !any) restore_all();
    if (last_recoil && !nr) restore_all();
    if (last_spread && !ns) restore_all();
    if (last_rapid  && !rf) restore_all();
    last_any = any; last_recoil = nr; last_spread = ns; last_rapid = rf;

    if (!any || !local_entity) return;

    uintptr_t C = get_wctx(local_entity);
    if (!C) return;

    WeaponSnapshot* s = get_snapshot(local_entity, true);
    if (!s) return;

    int mode = lunar::g_cfg.recoil_mode.load();
    if (mode == 2) return; // off

    if (nr) {
        float k = (mode == 0) ? 0.f : lunar::g_cfg.recoil_scale.load();
        apply_recoil(C, s, k);
    }

    if (ns) {
        float k = (mode == 0) ? 0.f : lunar::g_cfg.spread_scale.load();
        apply_spread(C, s, k);
    }

    if (rf) {
        apply_rapidfire(s);
    }
}

// ── Init: resolve NRK component method ──────────────────────────────────────
bool init() {
    // Try to resolve the NRK component getter
    // This varies by build — for OB54, it's typically through the component system
    uintptr_t m = il2cpp::get_method_offset(
        "Assembly-CSharp.dll", "COW.GamePlay",
        "Player", "get_NRKComponent", 0);
    if (m) {
        resolve_nrk = (uintptr_t(*)(uintptr_t))m;
        LOGI("NRK component resolver: %p", (void*)m);
    } else {
        LOGW("NRK component not found — norecoil needs manual offset");
    }
    return true;
}

} // namespace lunar_norecoil
