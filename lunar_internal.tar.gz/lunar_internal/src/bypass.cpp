// ============================================================================
//  ANTI-CHEAT BYPASS
//  Jittered AC facade patching + speedhack via TimeService
// ============================================================================

#include "lunar_config.h"
#include "il2cpp_api.h"
#include <cstring>
#include <cstdint>
#include <ctime>
#include <unistd.h>

namespace lunar_bypass {

// ── LCG PRNG for jitter timing ──────────────────────────────────────────────
static uint32_t g_rng = 0xDEADBEEF;

static uint32_t lcg_next() {
    g_rng = g_rng * 1664525u + 1013904223u;
    return g_rng;
}

static uint32_t jitter_ms() {
    uint32_t base = lunar::g_cfg.ac_repatch_base_ms.load();
    uint32_t jit  = (lcg_next() % 61) - 30;  // ±30ms
    int32_t  res  = (int32_t)base + (int32_t)jit;
    return res < 20 ? 20 : (uint32_t)res;
}

// ── AC facade patch ─────────────────────────────────────────────────────────
static uintptr_t g_ac_facade = 0;
static uint8_t   g_ac_orig[8] = {};
static bool      g_ac_saved = false;

static bool resolve_ac() {
    uintptr_t base = il2cpp::get_base();
    if (!base) return false;

    g_ac_facade = base + lunar::off::ac_facade;

    // Save original bytes
    memcpy(g_ac_orig, (void*)g_ac_facade, sizeof(g_ac_orig));
    g_ac_saved = true;

    LOGI("AC facade: %p (base+0x%lX)", (void*)g_ac_facade,
         (unsigned long)lunar::off::ac_facade);
    return true;
}

// ARM64: RET instruction = 0xD65F03C0
static const uint8_t kRetPatch[] = { 0xC0, 0x03, 0x5F, 0xD6 };

static void patch_ac() {
    if (!g_ac_facade || !g_ac_saved) return;

    // Make writable
    uintptr_t page = g_ac_facade & ~0xFFFUL;
    mprotect((void*)page, 0x2000, PROT_READ | PROT_WRITE | PROT_EXEC);

    // Write RET at entry — function returns immediately, skipping all checks
    memcpy((void*)g_ac_facade, kRetPatch, sizeof(kRetPatch));
    __builtin___clear_cache((char*)g_ac_facade, (char*)g_ac_facade + sizeof(kRetPatch));
}

static void restore_ac() {
    if (!g_ac_facade || !g_ac_saved) return;

    uintptr_t page = g_ac_facade & ~0xFFFUL;
    mprotect((void*)page, 0x2000, PROT_READ | PROT_WRITE | PROT_EXEC);

    memcpy((void*)g_ac_facade, g_ac_orig, sizeof(g_ac_orig));
    __builtin___clear_cache((char*)g_ac_facade, (char*)g_ac_facade + sizeof(g_ac_orig));
}

// ── AC field patching ───────────────────────────────────────────────────────
// ac_fields at offset 0xB8 from facade, flag at +0x20
static void zero_ac_fields() {
    if (!g_ac_facade) return;

    uintptr_t fields = g_ac_facade + lunar::off::ac_fields;
    if (fields < 0x100000) return;

    // Zero the detection flag
    *(uint32_t*)(fields + lunar::off::ac_flag) = 0;
}

// ── Speedhack via TimeService ───────────────────────────────────────────────
static uintptr_t g_speed_facade = 0;
static float     g_speed_orig   = 1.0f;
static bool      g_speed_saved  = false;

static bool resolve_speed() {
    uintptr_t base = il2cpp::get_base();
    if (!base) return false;

    g_speed_facade = base + lunar::off::speed_facade;

    // Read original time scale
    g_speed_orig = *(float*)g_speed_facade;
    if (!(g_speed_orig > 0.f && g_speed_orig <= 10.f))
        g_speed_orig = 1.0f;
    g_speed_saved = true;

    LOGI("Speed facade: %p", (void*)g_speed_facade);
    return true;
}

static void apply_speed(float scale) {
    if (!g_speed_facade || !g_speed_saved) return;
    if (scale < 0.1f) scale = 0.1f;
    if (scale > 5.0f) scale = 5.0f;

    uintptr_t page = g_speed_facade & ~0xFFFUL;
    mprotect((void*)page, 0x1000, PROT_READ | PROT_WRITE);
    *(float*)g_speed_facade = scale;
}

static void restore_speed() {
    if (!g_speed_facade || !g_speed_saved) return;
    apply_speed(g_speed_orig);
}

// ── Thread stealth ──────────────────────────────────────────────────────────
void stealth_thread() {
    pthread_setname_np(pthread_self(), "UnityGfx");
    prctl(PR_SET_NAME, "UnityGfx", 0, 0, 0);
}

// ── Main bypass loop ────────────────────────────────────────────────────────
static volatile bool g_running = false;

static void* bypass_thread(void* /*arg*/) {
    stealth_thread();

    while (g_running) {
        if (lunar::g_cfg.bypass.load()) {
            patch_ac();
            zero_ac_fields();
        }

        if (lunar::g_cfg.speedhack.load()) {
            float s = lunar::g_cfg.speed_scale.load();
            apply_speed(s);
        }

        uint32_t wait = jitter_ms();
        usleep(wait * 1000);
    }

    // Cleanup on exit
    restore_ac();
    restore_speed();
    return nullptr;
}

// ── Public API ──────────────────────────────────────────────────────────────
bool init() {
    g_rng = (uint32_t)time(nullptr) ^ 0x55AA55AA;

    bool ok = resolve_ac();
    resolve_speed();  // optional, don't fail init if missing

    if (!ok) {
        LOGW("AC facade resolve failed — bypass won't work");
        return false;
    }

    g_running = true;
    pthread_t t;
    pthread_create(&t, nullptr, bypass_thread, nullptr);
    pthread_detach(t);

    LOGI("Bypass thread started ✿");
    return true;
}

void shutdown() {
    g_running = false;
    usleep(200 * 1000);  // wait for thread to clean up
}

} // namespace lunar_bypass
