// ============================================================================
//  AIMBOT — Legit, Rage, and endpoint-based silent aim
//  (OnCalcDamage silent is in hooks.cpp)
// ============================================================================

#include "lunar_config.h"
#include "unity_api.h"
#include <cmath>
#include <chrono>
#include <thread>
#include <pthread.h>
#include <sys/prctl.h>

namespace lunar_aim {

// ── Shot state tracking ─────────────────────────────────────────────────────
struct ShotState {
    void*  target    = nullptr;
    int    shots     = 0;
    bool   firing    = false;
    bool   headPhase = false;
    double lastEdge  = 0.0;
    double lastFire  = 0.0;
    double headSince = 0.0;
};

static ShotState g_shot;
static void*     g_bestEnemy = nullptr;

static double now_s() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

static void reset_shots(void* target) {
    g_shot.target    = target;
    g_shot.shots     = 0;
    g_shot.headPhase = false;
    g_shot.headSince = 0.0;
}

static void note_firing(bool firingNow) {
    const double now = now_s();

    if (firingNow && !g_shot.firing) {
        if ((now - g_shot.lastEdge) >= (double)lunar::aim::edge_gap_s) {
            if (g_shot.shots < lunar::aim::max_chest_shots)
                g_shot.shots++;
            g_shot.lastEdge = now;
        }
    }
    if (firingNow) {
        g_shot.lastFire = now;
    } else if ((now - g_shot.lastFire) > 2.5) {
        g_shot.shots     = 0;
        g_shot.headPhase = false;
    }
    g_shot.firing = firingNow;
}

static int resolve_aim_bone() {
    if (!lunar::g_cfg.aim_chest_then_head.load())
        return lunar::g_cfg.aim_bone.load();

    int cap = lunar::clampi(lunar::g_cfg.aim_chest_shots.load(), 0,
                            lunar::aim::max_chest_shots);
    if (cap <= 0) return lunar::g_cfg.aim_bone.load();

    if (g_shot.shots < cap) {
        g_shot.headPhase = false;
        return lunar::kChest;
    }

    const double now = now_s();
    if (!g_shot.headPhase) {
        g_shot.headPhase = true;
        g_shot.headSince = now;
    }
    if ((now - g_shot.headSince) * 1000.0 < (double)lunar::aim::head_delay_ms)
        return lunar::kChest;

    return lunar::kHead;
}

// ── Target selection ────────────────────────────────────────────────────────
static void* get_closest_enemy(void* match, void* local) {
    void* prev = g_bestEnemy;
    g_bestEnemy = nullptr;

    if (!local || !match) return nullptr;

    void* cam = unity::Camera_main();
    if (!cam) return nullptr;

    Vector3 lp = unity::getPosition(local);
    float cx = unity::screenWidth  * 0.5f;
    float cy = unity::screenHeight * 0.5f;
    float fovPx    = lunar::g_cfg.aim_fov.load();
    float stickyPx = fovPx * lunar::aim::sticky_fov_mul;

    unity::PlayerDict* dict = unity::GetPlayerList(match);
    if (!dict || !dict->entries || dict->count <= 0) return nullptr;

    void* best = nullptr;
    float bestScore = 1e9f;
    void* sticky = nullptr;

    for (int i = 0; i < dict->count && i < 512; i++) {
        void* player = dict->entries[i].value;
        if (!player || player == local) continue;
        if (unity::get_isLocalTeam && unity::get_isLocalTeam(player)) continue;
        if (unity::get_IsDieing && unity::get_IsDieing(player)) continue;
        if (unity::get_MaxHP && unity::get_MaxHP(player) <= 0) continue;

        Vector3 pp = unity::getPosition(player);
        float dist = Vector3::Distance(lp, pp);
        if (dist > 300.f) continue;

        Vector3 headPos = unity::GetHeadPosition ?
                          unity::GetHeadPosition(player) : pp;
        Vector2 s2d;
        if (!unity::WorldToScreen(headPos, s2d)) continue;

        // screen distance (Manhattan for speed)
        float sd = fabsf(s2d.x - cx) + fabsf(s2d.y - cy);
        float fovLimit = (player == prev) ? stickyPx : fovPx;
        if (sd > fovLimit) continue;

        if (lunar::g_cfg.aim_visible_only.load() &&
            unity::get_isVisible && !unity::get_isVisible(player))
            continue;

        float score = sd + dist * lunar::aim::dist_penalty;
        if (player == prev) sticky = player;
        if (score < bestScore) { bestScore = score; best = player; }
    }

    if (lunar::g_cfg.aim_sticky.load() && sticky) return g_bestEnemy = sticky;
    g_bestEnemy = best;
    return g_bestEnemy;
}

// ── Adjusted position (respects chest→head delay) ───────────────────────────
static Vector3 get_adjusted_pos(void* enemy) {
    Vector3 head = unity::GetHeadPosition(enemy);
    int bone = resolve_aim_bone();

    if (bone == lunar::kNeck) {
        head.y += lunar::aim::neck_offset;
    } else if (bone == lunar::kChest) {
        Vector3 hip = unity::GetHipPosition ? unity::GetHipPosition(enemy) : head;
        head = Vector3::Lerp(head, hip, lunar::aim::chest_lerp);
    } else if (bone == lunar::kHip) {
        head = unity::GetHipPosition ? unity::GetHipPosition(enemy) : head;
    }
    return head;
}

// ── Rotation math ───────────────────────────────────────────────────────────
static Quaternion rotation_to_target(Vector3 target, Vector3 from) {
    Vector3 dir = Vector3::Normalized(target - from);
    float yaw   = atan2f(dir.x, dir.z);
    float pitch = -asinf(dir.y);

    // Quaternion from euler (yaw around Y, pitch around X)
    float cy = cosf(yaw * 0.5f), sy = sinf(yaw * 0.5f);
    float cp = cosf(pitch * 0.5f), sp = sinf(pitch * 0.5f);

    return {
        .x = sp * cy,
        .y = cp * sy,
        .z = -sp * sy,
        .w = cp * cy
    };
}

// ── Main tick (called from game thread) ─────────────────────────────────────
void tick() {
    if (!lunar::g_cfg.aim_enabled.load()) return;
    if (!unity::Curent_Match || !unity::GetLocalPlayer || !unity::getPosition) return;

    void* match = unity::Curent_Match();
    if (!match) return;

    void* local = unity::GetLocalPlayer(match);
    if (!local) return;

    void* enemy = get_closest_enemy(match, local);
    if (enemy != g_shot.target) reset_shots(enemy);

    bool firing = unity::get_IsFiring ? unity::get_IsFiring(local) : false;
    note_firing(firing);

    if (!enemy) return;

    int mode = lunar::g_cfg.aim_mode.load();
    Vector3 aimPos = get_adjusted_pos(enemy);
    Vector3 myPos  = unity::getPosition(local);

    // Check FOV
    Vector2 s2d;
    if (!unity::WorldToScreen(aimPos, s2d)) return;
    float cx = unity::screenWidth * 0.5f;
    float cy = unity::screenHeight * 0.5f;
    float sd = fabsf(s2d.x - cx) + fabsf(s2d.y - cy);
    if (sd > lunar::g_cfg.aim_fov.load()) return;

    Quaternion targetRot = rotation_to_target(aimPos, myPos);

    if (!unity::set_aim2) return;

    switch (mode) {
        case 0: // Legit — only when firing + scoped
            if (firing || (unity::get_IsSighting && unity::get_IsSighting(local)))
                unity::set_aim2(local, targetRot);
            break;

        case 1: // Rage — always lock
            unity::set_aim2(local, targetRot);
            break;

        case 2: // Silent endpoint (endPos override) — legacy
            if (firing) {
                // This is handled by the OnCalcDamage hook in hooks.cpp
                // But as fallback, we can redirect endPos if the match exposes it
            }
            break;
    }
}

// ── Stealth thread wrapper ──────────────────────────────────────────────────
static bool g_running = true;

void thread_func() {
    if (lunar::g_cfg.hide_threads.load()) {
        pthread_setname_np(pthread_self(), "UnityGfx");
        prctl(PR_SET_NAME, "UnityGfx", 0, 0, 0);
    }

    while (g_running) {
        tick();
        usleep(1000); // 1ms tick
    }
}

void start() {
    g_running = true;
    pthread_t t;
    pthread_create(&t, nullptr, [](void*) -> void* {
        thread_func();
        return nullptr;
    }, nullptr);
    pthread_detach(t);
}

void stop() {
    g_running = false;
}

} // namespace lunar_aim
