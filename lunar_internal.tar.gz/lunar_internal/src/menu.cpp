// ============================================================================
//  TOUCH MENU — ImGui-based feature toggle for Android
//  Opens/closes with 3-finger tap, renders over game via eglSwapBuffers hook
// ============================================================================

#include "lunar_config.h"
#include <android/input.h>
#include <cstring>
#include <cmath>

// ImGui forward declarations (linked from imgui/)
struct ImGuiContext;
namespace ImGui {
    extern ImGuiContext* CreateContext();
    extern void DestroyContext(ImGuiContext*);
    extern void StyleColorsDark();
    extern void NewFrame();
    extern void Render();
    extern void EndFrame();
    extern bool Begin(const char*, bool*, int = 0);
    extern void End();
    extern bool Checkbox(const char*, bool*);
    extern bool SliderFloat(const char*, float*, float, float, const char* = "%.2f", int = 0);
    extern bool SliderInt(const char*, int*, int, int, const char* = "%d", int = 0);
    extern void Text(const char*, ...);
    extern void Separator();
    extern void SameLine(float = 0, float = -1);
    extern bool CollapsingHeader(const char*, int = 0);
    extern bool RadioButton(const char*, int*, int);
    extern void SetNextWindowSize(float, float, int = 0);
    extern void SetNextWindowPos(float, float, int = 0, float = 0, float = 0);
    extern struct ImGuiIO& GetIO();
}

// ImGui backend forward declarations
namespace ImGui_ImplOpenGL3 {
    extern bool Init(const char*);
    extern void Shutdown();
    extern void NewFrame();
    extern void RenderDrawData(void*);
}

namespace ImGui_ImplAndroid {
    extern bool Init(void*);
    extern void Shutdown();
    extern void NewFrame();
}

namespace lunar_menu {

static bool       g_initialized = false;
static bool       g_visible     = false;
static int        g_touch_count = 0;
static uint64_t   g_last_toggle = 0;

// ── Touch tracking for 3-finger toggle ──────────────────────────────────────
static uint64_t now_ms() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

void on_touch(int action, int pointer_count) {
    if (pointer_count >= 3 && action == 0 /* ACTION_DOWN */) {
        uint64_t now = now_ms();
        if (now - g_last_toggle > 500) {
            g_visible = !g_visible;
            g_last_toggle = now;
        }
    }
    g_touch_count = pointer_count;
}

bool is_visible() { return g_visible; }

// ── Init ImGui ──────────────────────────────────────────────────────────────
bool init(int width, int height) {
    if (g_initialized) return true;

    ImGui::CreateContext();
    ImGui::StyleColorsDark();

    auto& io = ImGui::GetIO();
    io.DisplaySize.x = (float)width;
    io.DisplaySize.y = (float)height;

    ImGui_ImplOpenGL3::Init("#version 300 es");
    ImGui_ImplAndroid::Init(nullptr);

    g_initialized = true;
    LOGI("Menu initialized %dx%d", width, height);
    return true;
}

// ── Render menu ─────────────────────────────────────────────────────────────
void render(int width, int height) {
    if (!g_initialized || !g_visible) return;

    auto& io = ImGui::GetIO();
    io.DisplaySize.x = (float)width;
    io.DisplaySize.y = (float)height;

    ImGui_ImplOpenGL3::NewFrame();
    ImGui_ImplAndroid::NewFrame();
    ImGui::NewFrame();

    // Menu window
    float mw = width * 0.65f;
    float mh = height * 0.75f;
    ImGui::SetNextWindowSize(mw, mh, 1 << 1 /* ImGuiCond_FirstUseEver */);
    ImGui::SetNextWindowPos(width * 0.175f, height * 0.125f, 1 << 1);

    bool open = true;
    if (ImGui::Begin("Lunar ✿ OB54", &open, 0)) {

        // ── ESP Section ─────────────────────────────────────
        if (ImGui::CollapsingHeader("ESP")) {
            bool esp = lunar::g_cfg.esp.load();
            if (ImGui::Checkbox("ESP Enabled", &esp))
                lunar::g_cfg.esp.store(esp);

            if (esp) {
                bool box   = lunar::g_cfg.esp_box.load();
                bool hp    = lunar::g_cfg.esp_hp.load();
                bool dist  = lunar::g_cfg.esp_dist.load();
                bool snap  = lunar::g_cfg.esp_snap.load();

                if (ImGui::Checkbox("Box",      &box))  lunar::g_cfg.esp_box.store(box);
                ImGui::SameLine();
                if (ImGui::Checkbox("HP Bar",   &hp))   lunar::g_cfg.esp_hp.store(hp);
                if (ImGui::Checkbox("Distance", &dist)) lunar::g_cfg.esp_dist.store(dist);
                ImGui::SameLine();
                if (ImGui::Checkbox("Snapline", &snap)) lunar::g_cfg.esp_snap.store(snap);

                float max_d = lunar::g_cfg.esp_max_dist.load();
                if (ImGui::SliderFloat("Max Distance", &max_d, 50.f, 500.f))
                    lunar::g_cfg.esp_max_dist.store(max_d);
            }
        }

        ImGui::Separator();

        // ── Aimbot Section ──────────────────────────────────
        if (ImGui::CollapsingHeader("Aimbot")) {
            int mode = lunar::g_cfg.aim_mode.load();
            ImGui::Text("Mode:");
            ImGui::RadioButton("Off",    &mode, 0);
            ImGui::SameLine();
            ImGui::RadioButton("Legit",  &mode, 1);
            ImGui::SameLine();
            ImGui::RadioButton("Rage",   &mode, 2);
            lunar::g_cfg.aim_mode.store(mode);

            if (mode > 0) {
                float fov = lunar::g_cfg.aim_fov.load();
                if (ImGui::SliderFloat("FOV", &fov, 1.f, 90.f))
                    lunar::g_cfg.aim_fov.store(fov);

                float smooth = lunar::g_cfg.aim_smooth.load();
                if (ImGui::SliderFloat("Smooth", &smooth, 1.f, 20.f))
                    lunar::g_cfg.aim_smooth.store(smooth);

                int bone = lunar::g_cfg.aim_bone.load();
                ImGui::Text("Bone:");
                ImGui::RadioButton("Head",  &bone, 0);
                ImGui::SameLine();
                ImGui::RadioButton("Neck",  &bone, 1);
                ImGui::SameLine();
                ImGui::RadioButton("Chest", &bone, 2);
                ImGui::SameLine();
                ImGui::RadioButton("Smart", &bone, 4);
                lunar::g_cfg.aim_bone.store(bone);

                if (bone == 4) {
                    int chest_n = lunar::g_cfg.chest_first_n.load();
                    if (ImGui::SliderInt("Chest-first N", &chest_n, 1, 15))
                        lunar::g_cfg.chest_first_n.store(chest_n);

                    float delay = lunar::g_cfg.head_switch_delay.load();
                    if (ImGui::SliderFloat("Head delay (s)", &delay, 0.f, 2.f))
                        lunar::g_cfg.head_switch_delay.store(delay);
                }
            }
        }

        ImGui::Separator();

        // ── Silent Aim Section ──────────────────────────────
        if (ImGui::CollapsingHeader("Silent Aim")) {
            bool sa = lunar::g_cfg.silent_aim.load();
            if (ImGui::Checkbox("Silent Aim", &sa))
                lunar::g_cfg.silent_aim.store(sa);

            if (sa) {
                float sa_fov = lunar::g_cfg.silent_fov.load();
                if (ImGui::SliderFloat("Silent FOV", &sa_fov, 1.f, 180.f))
                    lunar::g_cfg.silent_fov.store(sa_fov);
            }
        }

        ImGui::Separator();

        // ── Weapon Section ──────────────────────────────────
        if (ImGui::CollapsingHeader("Weapon")) {
            bool nr = lunar::g_cfg.norecoil.load();
            bool ns = lunar::g_cfg.nospread.load();
            bool rf = lunar::g_cfg.rapidfire.load();

            if (ImGui::Checkbox("No Recoil", &nr))  lunar::g_cfg.norecoil.store(nr);
            if (ImGui::Checkbox("No Spread", &ns))   lunar::g_cfg.nospread.store(ns);
            if (ImGui::Checkbox("Rapid Fire", &rf))  lunar::g_cfg.rapidfire.store(rf);

            if (nr || ns) {
                int rmode = lunar::g_cfg.recoil_mode.load();
                ImGui::Text("Recoil Mode:");
                ImGui::RadioButton("Zero",    &rmode, 0);
                ImGui::SameLine();
                ImGui::RadioButton("Stealth", &rmode, 1);
                ImGui::SameLine();
                ImGui::RadioButton("Off",     &rmode, 2);
                lunar::g_cfg.recoil_mode.store(rmode);

                if (rmode == 1) {
                    float rk = lunar::g_cfg.recoil_scale.load();
                    float sk = lunar::g_cfg.spread_scale.load();
                    if (ImGui::SliderFloat("Recoil %", &rk, 0.f, 1.f))
                        lunar::g_cfg.recoil_scale.store(rk);
                    if (ImGui::SliderFloat("Spread %", &sk, 0.f, 1.f))
                        lunar::g_cfg.spread_scale.store(sk);
                }
            }
        }

        ImGui::Separator();

        // ── Bypass Section ──────────────────────────────────
        if (ImGui::CollapsingHeader("Bypass")) {
            bool bp = lunar::g_cfg.bypass.load();
            if (ImGui::Checkbox("AC Bypass", &bp))
                lunar::g_cfg.bypass.store(bp);

            bool sh = lunar::g_cfg.speedhack.load();
            if (ImGui::Checkbox("Speedhack", &sh))
                lunar::g_cfg.speedhack.store(sh);

            if (sh) {
                float spd = lunar::g_cfg.speed_scale.load();
                if (ImGui::SliderFloat("Speed", &spd, 0.5f, 3.0f))
                    lunar::g_cfg.speed_scale.store(spd);
            }
        }

        ImGui::Text("\n3-finger tap to toggle menu");
    }
    ImGui::End();

    if (!open) g_visible = false;

    ImGui::Render();
    ImGui_ImplOpenGL3::RenderDrawData(ImGui::GetDrawData());
}

// ── Shutdown ────────────────────────────────────────────────────────────────
void shutdown() {
    if (!g_initialized) return;
    ImGui_ImplOpenGL3::Shutdown();
    ImGui_ImplAndroid::Shutdown();
    ImGui::DestroyContext(nullptr);
    g_initialized = false;
}

} // namespace lunar_menu
