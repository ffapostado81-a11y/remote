// ============================================================================
//  ESP — OpenGL ES overlay rendering
//  Draws boxes, HP bars, names, distance, snap lines
// ============================================================================

#include "lunar_config.h"
#include "unity_api.h"
#include <GLES3/gl3.h>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>

namespace lunar_esp {

// ── GL state ────────────────────────────────────────────────────────────────
static GLuint g_shader = 0;
static GLuint g_vao = 0;
static GLuint g_vbo = 0;
static GLint  g_loc_proj = -1;
static GLint  g_loc_color = -1;
static bool   g_ready = false;

struct Vertex { float x, y; };

bool gl_ready() { return g_ready; }

// ── Shaders ─────────────────────────────────────────────────────────────────
static const char* vs_src = R"(#version 300 es
layout(location=0) in vec2 pos;
uniform mat4 proj;
void main() { gl_Position = proj * vec4(pos, 0.0, 1.0); }
)";

static const char* fs_src = R"(#version 300 es
precision mediump float;
uniform vec4 color;
out vec4 fragColor;
void main() { fragColor = color; }
)";

static GLuint compile_shader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    return s;
}

void init_gl() {
    GLuint vs = compile_shader(GL_VERTEX_SHADER, vs_src);
    GLuint fs = compile_shader(GL_FRAGMENT_SHADER, fs_src);

    g_shader = glCreateProgram();
    glAttachShader(g_shader, vs);
    glAttachShader(g_shader, fs);
    glLinkProgram(g_shader);
    glDeleteShader(vs);
    glDeleteShader(fs);

    g_loc_proj  = glGetUniformLocation(g_shader, "proj");
    g_loc_color = glGetUniformLocation(g_shader, "color");

    glGenVertexArrays(1, &g_vao);
    glGenBuffers(1, &g_vbo);

    glBindVertexArray(g_vao);
    glBindBuffer(GL_ARRAY_BUFFER, g_vbo);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), nullptr);
    glBindVertexArray(0);

    g_ready = true;
}

// ── Drawing primitives ──────────────────────────────────────────────────────
static void set_ortho(float w, float h) {
    float proj[16] = {
        2.f/w, 0, 0, 0,
        0, -2.f/h, 0, 0,
        0, 0, -1, 0,
        -1, 1, 0, 1
    };
    glUniformMatrix4fv(g_loc_proj, 1, GL_FALSE, proj);
}

static void draw_lines(const Vertex* verts, int count, float r, float g, float b, float a, float width) {
    glUniform4f(g_loc_color, r, g, b, a);
    glLineWidth(width);
    glBindBuffer(GL_ARRAY_BUFFER, g_vbo);
    glBufferData(GL_ARRAY_BUFFER, count * sizeof(Vertex), verts, GL_DYNAMIC_DRAW);
    glDrawArrays(GL_LINES, 0, count);
}

static void draw_rect(float x, float y, float w, float h, float r, float g, float b, float a, float lw) {
    Vertex v[8] = {
        {x, y},     {x+w, y},
        {x+w, y},   {x+w, y+h},
        {x+w, y+h}, {x, y+h},
        {x, y+h},   {x, y},
    };
    draw_lines(v, 8, r, g, b, a, lw);
}

static void draw_filled_rect(float x, float y, float w, float h, float r, float g, float b, float a) {
    Vertex v[6] = {
        {x, y}, {x+w, y}, {x, y+h},
        {x+w, y}, {x+w, y+h}, {x, y+h}
    };
    glUniform4f(g_loc_color, r, g, b, a);
    glBindBuffer(GL_ARRAY_BUFFER, g_vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(v), v, GL_DYNAMIC_DRAW);
    glDrawArrays(GL_TRIANGLES, 0, 6);
}

static void draw_line(float x1, float y1, float x2, float y2, float r, float g, float b, float a, float w) {
    Vertex v[2] = {{x1, y1}, {x2, y2}};
    draw_lines(v, 2, r, g, b, a, w);
}

// ── Corner box (looks nicer than full box) ──────────────────────────────────
static void draw_corner_box(float x, float y, float w, float h,
                            float r, float g, float b, float a, float lw) {
    float corner = w * 0.25f;
    if (corner < 4.f) corner = 4.f;

    Vertex v[16] = {
        // Top-left
        {x, y}, {x + corner, y},
        {x, y}, {x, y + corner},
        // Top-right
        {x+w, y}, {x+w - corner, y},
        {x+w, y}, {x+w, y + corner},
        // Bottom-left
        {x, y+h}, {x + corner, y+h},
        {x, y+h}, {x, y+h - corner},
        // Bottom-right
        {x+w, y+h}, {x+w - corner, y+h},
        {x+w, y+h}, {x+w, y+h - corner},
    };
    draw_lines(v, 16, r, g, b, a, lw);
}

// ── Main render ─────────────────────────────────────────────────────────────
void render(int width, int height) {
    if (!g_ready || !unity::Curent_Match || !unity::GetLocalPlayer ||
        !unity::getPosition || !unity::Camera_main) return;

    void* match = unity::Curent_Match();
    if (!match) return;

    void* local = unity::GetLocalPlayer(match);
    if (!local) return;

    void* cam = unity::Camera_main();
    if (!cam) return;

    Vector3 myPos = unity::getPosition(local);
    unity::PlayerDict* dict = unity::GetPlayerList(match);
    if (!dict || !dict->entries || dict->count <= 0) return;

    float sw = (float)width;
    float sh = (float)height;
    int maxDist = lunar::g_cfg.esp_max_dist.load();

    // Save GL state
    GLint prev_prog;  glGetIntegerv(GL_CURRENT_PROGRAM, &prev_prog);
    GLboolean blend;  glGetBooleanv(GL_BLEND, &blend);
    GLboolean depth;  glGetBooleanv(GL_DEPTH_TEST, &depth);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_DEPTH_TEST);

    glUseProgram(g_shader);
    glBindVertexArray(g_vao);
    set_ortho(sw, sh);

    for (int i = 0; i < dict->count && i < 512; i++) {
        void* enemy = dict->entries[i].value;
        if (!enemy || enemy == local) continue;
        if (unity::get_isLocalTeam && unity::get_isLocalTeam(enemy)) continue;
        if (unity::get_IsDieing && unity::get_IsDieing(enemy)) continue;
        if (unity::get_MaxHP && unity::get_MaxHP(enemy) <= 0) continue;

        Vector3 ePos = unity::getPosition(enemy);
        float dist = Vector3::Distance(myPos, ePos);
        if (dist > (float)maxDist || dist < 1.f) continue;

        // Project feet and head
        Vector2 screenFeet, screenHead;
        if (!unity::WorldToScreen(ePos, screenFeet)) continue;

        Vector3 headPos = unity::GetHeadPosition ?
                          unity::GetHeadPosition(enemy) : ePos;
        headPos.y += 0.3f; // slight offset above head
        if (!unity::WorldToScreen(headPos, screenHead)) continue;

        float boxH = fabsf(screenFeet.y - screenHead.y);
        if (boxH < 5.f) continue;
        float boxW = boxH * 0.55f;
        float boxX = screenHead.x - boxW * 0.5f;
        float boxY = screenHead.y;

        // Determine if enemy (red) or teammate (green)
        float cr = 1.f, cg = 0.2f, cb = 0.2f;

        // ── Corner Box ──
        if (lunar::g_cfg.esp_box.load()) {
            draw_corner_box(boxX, boxY, boxW, boxH, cr, cg, cb, 0.9f, 2.f);
        }

        // ── HP Bar ──
        if (lunar::g_cfg.esp_hp.load() && unity::get_CurrentHP && unity::get_MaxHP) {
            float hp = unity::get_CurrentHP(enemy);
            float maxHp = unity::get_MaxHP(enemy);
            if (maxHp > 0) {
                float ratio = hp / maxHp;
                if (ratio > 1.f) ratio = 1.f;
                if (ratio < 0.f) ratio = 0.f;

                float barW = 3.f;
                float barX = boxX - barW - 2.f;
                float barH = boxH * ratio;
                float barY = boxY + (boxH - barH);

                // Background
                draw_filled_rect(barX, boxY, barW, boxH, 0.f, 0.f, 0.f, 0.5f);
                // Fill (green->yellow->red based on HP)
                float hr = (ratio < 0.5f) ? 1.f : 1.f - (ratio - 0.5f) * 2.f;
                float hg = (ratio > 0.5f) ? 1.f : ratio * 2.f;
                draw_filled_rect(barX, barY, barW, barH, hr, hg, 0.f, 0.8f);
            }
        }

        // ── Distance ──
        if (lunar::g_cfg.esp_distance.load()) {
            // Distance shown at feet as a small indicator
            // (text rendering requires font atlas — use colored bar as distance indicator)
            float distRatio = 1.f - (dist / (float)maxDist);
            float barW2 = boxW * distRatio;
            draw_filled_rect(boxX, screenFeet.y + 2.f, barW2, 2.f, 0.5f, 0.5f, 1.f, 0.6f);
        }

        // ── Snap Line ──
        if (lunar::g_cfg.esp_line.load()) {
            draw_line(sw * 0.5f, sh, screenFeet.x, screenFeet.y,
                      1.f, 1.f, 1.f, 0.3f, 1.f);
        }
    }

    // Restore GL state
    glBindVertexArray(0);
    glUseProgram(prev_prog);
    if (!blend) glDisable(GL_BLEND);
    if (depth) glEnable(GL_DEPTH_TEST);
}

} // namespace lunar_esp
