// ============================================================================
//  INJECTOR HELPERS — ptrace-based .so injection for Android ARM64
//  Used by inject_main.cpp to load lunar.so into the game process
// ============================================================================

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <dlfcn.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <elf.h>
#include <linux/elf.h>

#define TAG "LunarInject"
#define LOGI(fmt, ...) printf("[" TAG "] " fmt "\n", ##__VA_ARGS__)
#define LOGE(fmt, ...) fprintf(stderr, "[" TAG " ERR] " fmt "\n", ##__VA_ARGS__)

namespace lunar_inject {

// ── Find PID by package name ────────────────────────────────────────────────
pid_t find_pid(const char* pkg) {
    DIR* d = opendir("/proc");
    if (!d) return -1;

    struct dirent* ent;
    while ((ent = readdir(d))) {
        if (ent->d_type != DT_DIR) continue;

        int pid = atoi(ent->d_name);
        if (pid <= 0) continue;

        char path[256], name[256];
        snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);

        FILE* f = fopen(path, "r");
        if (!f) continue;

        memset(name, 0, sizeof(name));
        fread(name, 1, sizeof(name) - 1, f);
        fclose(f);

        if (strcmp(name, pkg) == 0) {
            closedir(d);
            LOGI("Found %s at PID %d", pkg, pid);
            return (pid_t)pid;
        }
    }

    closedir(d);
    return -1;
}

// ── Get module base from /proc/pid/maps ─────────────────────────────────────
uintptr_t get_remote_module_base(pid_t pid, const char* module) {
    char path[128];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);

    FILE* f = fopen(path, "r");
    if (!f) return 0;

    char line[512];
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, module) && strstr(line, "r-xp")) {
            uintptr_t base = 0;
            sscanf(line, "%lx", &base);
            fclose(f);
            return base;
        }
    }

    fclose(f);
    return 0;
}

// ── Get local module base ───────────────────────────────────────────────────
uintptr_t get_local_module_base(const char* module) {
    return get_remote_module_base(getpid(), module);
}

// ── Calculate remote function address ───────────────────────────────────────
uintptr_t get_remote_func(pid_t pid, const char* module, void* local_func) {
    uintptr_t local_base  = get_local_module_base(module);
    uintptr_t remote_base = get_remote_module_base(pid, module);

    if (!local_base || !remote_base) return 0;

    uintptr_t offset = (uintptr_t)local_func - local_base;
    return remote_base + offset;
}

// ── Read/write remote process memory via ptrace ─────────────────────────────
bool ptrace_read(pid_t pid, uintptr_t addr, void* buf, size_t len) {
    struct iovec local  = { buf, len };
    struct iovec remote = { (void*)addr, len };
    return process_vm_readv(pid, &local, 1, &remote, 1, 0) == (ssize_t)len;
}

bool ptrace_write(pid_t pid, uintptr_t addr, const void* buf, size_t len) {
    struct iovec local  = { (void*)buf, len };
    struct iovec remote = { (void*)addr, len };
    return process_vm_writev(pid, &local, 1, &remote, 1, 0) == (ssize_t)len;
}

// ── Allocate memory in remote process ───────────────────────────────────────
uintptr_t remote_mmap(pid_t pid, size_t size) {
    // Get remote mmap address
    uintptr_t remote_mmap_addr = get_remote_func(pid, "libc.so", (void*)mmap);
    if (!remote_mmap_addr) {
        LOGE("Cannot find remote mmap");
        return 0;
    }

    // Save registers
    struct user_regs_struct regs, saved_regs;
    struct iovec iov = { &regs, sizeof(regs) };
    ptrace(PTRACE_GETREGSET, pid, NT_PRSTATUS, &iov);
    memcpy(&saved_regs, &regs, sizeof(regs));

    // Setup mmap call: mmap(NULL, size, PROT_RWX, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0)
    regs.regs[0] = 0;                                    // addr = NULL
    regs.regs[1] = size;                                  // length
    regs.regs[2] = PROT_READ | PROT_WRITE | PROT_EXEC;   // prot
    regs.regs[3] = MAP_PRIVATE | MAP_ANONYMOUS;           // flags
    regs.regs[4] = (uint64_t)-1;                          // fd
    regs.regs[5] = 0;                                     // offset
    regs.pc = remote_mmap_addr;
    regs.regs[30] = 0;  // LR = 0 → will SIGSEGV after return

    iov.iov_base = &regs;
    ptrace(PTRACE_SETREGSET, pid, NT_PRSTATUS, &iov);
    ptrace(PTRACE_CONT, pid, 0, 0);

    // Wait for SIGSEGV (return to LR=0)
    int status;
    waitpid(pid, &status, 0);

    // Get return value (x0 = allocated address)
    iov.iov_base = &regs;
    ptrace(PTRACE_GETREGSET, pid, NT_PRSTATUS, &iov);
    uintptr_t result = regs.regs[0];

    // Restore original registers
    iov.iov_base = &saved_regs;
    ptrace(PTRACE_SETREGSET, pid, NT_PRSTATUS, &iov);

    if (result == (uintptr_t)MAP_FAILED) {
        LOGE("Remote mmap failed");
        return 0;
    }

    LOGI("Remote mmap: %p (%zu bytes)", (void*)result, size);
    return result;
}

// ── Call dlopen in remote process ───────────────────────────────────────────
bool remote_dlopen(pid_t pid, const char* lib_path) {
    // Get remote dlopen
    uintptr_t remote_dlopen_addr = get_remote_func(pid, "libdl.so", (void*)dlopen);
    if (!remote_dlopen_addr) {
        // Try linker
        remote_dlopen_addr = get_remote_func(pid, "linker64", (void*)dlopen);
    }
    if (!remote_dlopen_addr) {
        LOGE("Cannot find remote dlopen");
        return false;
    }

    // Allocate space for path string in remote process
    size_t path_len = strlen(lib_path) + 1;
    uintptr_t remote_path = remote_mmap(pid, 0x1000);
    if (!remote_path) return false;

    // Write path string to remote memory
    if (!ptrace_write(pid, remote_path, lib_path, path_len)) {
        LOGE("Cannot write path to remote");
        return false;
    }

    // Save registers
    struct user_regs_struct regs, saved_regs;
    struct iovec iov = { &regs, sizeof(regs) };
    ptrace(PTRACE_GETREGSET, pid, NT_PRSTATUS, &iov);
    memcpy(&saved_regs, &regs, sizeof(regs));

    // Call dlopen(path, RTLD_NOW)
    regs.regs[0] = remote_path;   // filename
    regs.regs[1] = RTLD_NOW;      // flags
    regs.pc = remote_dlopen_addr;
    regs.regs[30] = 0;            // LR = 0

    iov.iov_base = &regs;
    ptrace(PTRACE_SETREGSET, pid, NT_PRSTATUS, &iov);
    ptrace(PTRACE_CONT, pid, 0, 0);

    int status;
    waitpid(pid, &status, 0);

    // Get return value
    iov.iov_base = &regs;
    ptrace(PTRACE_GETREGSET, pid, NT_PRSTATUS, &iov);
    uintptr_t handle = regs.regs[0];

    // Restore
    iov.iov_base = &saved_regs;
    ptrace(PTRACE_SETREGSET, pid, NT_PRSTATUS, &iov);

    if (!handle) {
        LOGE("Remote dlopen returned NULL");
        return false;
    }

    LOGI("Remote dlopen success: handle=%p", (void*)handle);
    return true;
}

// ── Full injection sequence ─────────────────────────────────────────────────
bool inject(pid_t pid, const char* lib_path) {
    LOGI("Injecting %s into PID %d", lib_path, pid);

    // Attach
    if (ptrace(PTRACE_ATTACH, pid, 0, 0) < 0) {
        LOGE("PTRACE_ATTACH failed (need root or same UID)");
        return false;
    }

    int status;
    waitpid(pid, &status, 0);
    LOGI("Attached to process");

    // Perform injection
    bool ok = remote_dlopen(pid, lib_path);

    // Detach
    ptrace(PTRACE_DETACH, pid, 0, 0);
    LOGI("Detached from process");

    return ok;
}

} // namespace lunar_inject
