// ============================================================================
//  LUNAR INTERNAL — Entry Point
//  JNI_OnLoad / constructor attribute — initializes all subsystems
//  Target: Free Fire MAX OB54, Unity IL2CPP, ARM64-v8a
// ============================================================================

#include "lunar_config.h"
#include "il2cpp_api.h"
#include "unity_api.h"
#include "dobby_hook.h"
#include <jni.h>
#include <unistd.h>
#include <pthread.h>
#include <dlfcn.h>
#include <sys/prctl.h>
#include <cstring>
#include <cstdio>

// ── External subsystem declarations ─────────────────────────────────────────
namespace lunar_hooks    { bool install(); void uninstall(); }
namespace lunar_bypass   { bool init(); void shutdown(); void stealth_thread(); }
namespace lunar_norecoil { bool init(); }

// ── Wait for IL2CPP to be loaded ────────────────────────────────────────────
static bool wait_for_il2cpp(int timeout_sec) {
    LOGI("Waiting for libil2cpp.so...");

    for (int i = 0; i < timeout_sec * 10; i++) {
        void* h = dlopen("libil2cpp.so", RTLD_NOLOAD | RTLD_NOW);
        if (h) {
            dlclose(h);
            LOGI("libil2cpp.so found after %dms", i * 100);
            usleep(500 * 1000);  // let it finish initializing
            return true;
        }
        usleep(100 * 1000);
    }

    LOGE("libil2cpp.so not found after %ds!", timeout_sec);
    return false;
}

// ── Wait for Unity to be ready ──────────────────────────────────────────────
static bool wait_for_unity(int timeout_sec) {
    LOGI("Waiting for Unity init...");

    for (int i = 0; i < timeout_sec * 10; i++) {
        // Check if il2cpp_domain_get returns non-null
        void* h = dlopen("libil2cpp.so", RTLD_NOLOAD | RTLD_NOW);
        if (h) {
            auto fn = (void*(*)())dlsym(h, "il2cpp_domain_get");
            dlclose(h);
            if (fn) {
                void* dom = fn();
                if (dom) {
                    LOGI("Unity domain ready after %dms", i * 100);
                    return true;
                }
            }
        }
        usleep(100 * 1000);
    }

    LOGE("Unity domain not ready after %ds!", timeout_sec);
    return false;
}

// ── Main initialization thread ──────────────────────────────────────────────
static void* lunar_main(void* /*arg*/) {
    // Stealth: rename thread
    pthread_setname_np(pthread_self(), "UnityMain");
    prctl(PR_SET_NAME, "UnityMain", 0, 0, 0);

    LOGI("=== LUNAR INTERNAL v1.0 — OB54 ===");
    LOGI("PID: %d, TID: %d", getpid(), gettid());

    // Step 1: Wait for IL2CPP
    if (!wait_for_il2cpp(30)) {
        LOGE("Aborting: IL2CPP not loaded");
        return nullptr;
    }

    // Step 2: Wait for Unity domain
    if (!wait_for_unity(15)) {
        LOGE("Aborting: Unity not initialized");
        return nullptr;
    }

    // Step 3: Initialize IL2CPP API
    if (!il2cpp::init()) {
        LOGE("IL2CPP init failed!");
        return nullptr;
    }
    LOGI("IL2CPP API initialized ✿");

    // Step 4: Initialize Unity API
    if (!unity::init()) {
        LOGW("Unity API partial init — some features may not work");
    }
    LOGI("Unity API initialized");

    // Step 5: Initialize anti-cheat bypass (start BEFORE hooks)
    lunar::g_cfg.bypass.store(true);  // Enable bypass by default
    if (lunar_bypass::init()) {
        LOGI("Bypass active ✿");
    } else {
        LOGW("Bypass init failed — proceeding anyway");
    }

    // Step 6: Initialize norecoil subsystem
    if (lunar_norecoil::init()) {
        LOGI("NoRecoil subsystem ready");
    }

    // Step 7: Install hooks (eglSwapBuffers + OnCalcDamage)
    if (lunar_hooks::install()) {
        LOGI("Hooks installed ✿✿✿");
    } else {
        LOGE("Hook installation failed!");
        return nullptr;
    }

    // Step 8: Enable default features
    lunar::g_cfg.esp.store(true);
    lunar::g_cfg.esp_box.store(true);
    lunar::g_cfg.esp_hp.store(true);
    lunar::g_cfg.esp_dist.store(true);
    lunar::g_cfg.esp_snap.store(true);

    LOGI("=== LUNAR READY — 3-finger tap for menu ===");
    LOGI("✿ All systems online ✿");

    // Keep thread alive for cleanup signal
    while (true) {
        usleep(1000 * 1000);
    }

    return nullptr;
}

// ── JNI_OnLoad — called when .so is loaded via System.loadLibrary ───────────
extern "C" __attribute__((visibility("default")))
jint JNI_OnLoad(JavaVM* vm, void* /*reserved*/) {
    LOGI("JNI_OnLoad — launching lunar_main thread");

    pthread_t t;
    pthread_create(&t, nullptr, lunar_main, nullptr);
    pthread_detach(t);

    return JNI_VERSION_1_6;
}

// ── Constructor — called when .so is loaded via dlopen/inject ────────────────
__attribute__((constructor))
static void lunar_ctor() {
    LOGI("Constructor — launching lunar_main thread");

    pthread_t t;
    pthread_create(&t, nullptr, lunar_main, nullptr);
    pthread_detach(t);
}

// ── Destructor — cleanup on unload ──────────────────────────────────────────
__attribute__((destructor))
static void lunar_dtor() {
    LOGI("Destructor — cleaning up");
    lunar_hooks::uninstall();
    lunar_bypass::shutdown();
}
