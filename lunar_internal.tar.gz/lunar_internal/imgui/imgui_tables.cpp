// STUB — Replace with real imgui_tables.cpp from https://github.com/ocornut/imgui
