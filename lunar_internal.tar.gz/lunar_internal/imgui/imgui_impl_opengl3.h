// STUB — Replace with real imgui_impl_opengl3.h from imgui/backends/
#pragma once
struct ImDrawData;
namespace ImGui_ImplOpenGL3 {
    bool Init(const char* glsl_version);
    void Shutdown();
    void NewFrame();
    void RenderDrawData(void* draw_data);
}
