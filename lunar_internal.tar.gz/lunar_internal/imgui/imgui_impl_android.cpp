// STUB — Replace with real imgui_impl_android.cpp from imgui/backends/
#include "imgui_impl_android.h"
namespace ImGui_ImplAndroid {
    bool Init(void*) { return true; }
    void Shutdown() {}
    void NewFrame() {}
}
