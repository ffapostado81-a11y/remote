// STUB — Replace with real imgui_impl_android.h from imgui/backends/
#pragma once
namespace ImGui_ImplAndroid {
    bool Init(void* window);
    void Shutdown();
    void NewFrame();
}
