// ============================================================================
//  ImGui STUB HEADER — Replace with real imgui.h from ocornut/imgui
//  This is a minimal stub so the project compiles structurally.
//  Download real ImGui: https://github.com/ocornut/imgui
// ============================================================================
#pragma once

struct ImVec2 { float x, y; ImVec2() : x(0), y(0) {} ImVec2(float _x, float _y) : x(_x), y(_y) {} };
struct ImVec4 { float x, y, z, w; };
struct ImDrawData;
struct ImGuiContext;

struct ImGuiIO {
    ImVec2 DisplaySize;
    float  DeltaTime = 1.0f/60.0f;
    float  FontGlobalScale = 1.0f;
};

namespace ImGui {
    ImGuiContext* CreateContext();
    void DestroyContext(ImGuiContext*);
    void StyleColorsDark();
    ImGuiIO& GetIO();
    void NewFrame();
    void Render();
    void EndFrame();
    ImDrawData* GetDrawData();

    bool Begin(const char* name, bool* p_open = nullptr, int flags = 0);
    void End();
    bool Checkbox(const char* label, bool* v);
    bool SliderFloat(const char* label, float* v, float v_min, float v_max, const char* format = "%.2f", int flags = 0);
    bool SliderInt(const char* label, int* v, int v_min, int v_max, const char* format = "%d", int flags = 0);
    void Text(const char* fmt, ...);
    void Separator();
    void SameLine(float offset_from_start_x = 0, float spacing = -1);
    bool CollapsingHeader(const char* label, int flags = 0);
    bool RadioButton(const char* label, int* v, int v_button);
    void SetNextWindowSize(float w, float h, int cond = 0);
    void SetNextWindowPos(float x, float y, int cond = 0, float pivot_x = 0, float pivot_y = 0);
}
