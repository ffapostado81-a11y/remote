// STUB — Replace with real imgui_impl_opengl3.cpp from imgui/backends/
#include "imgui_impl_opengl3.h"
namespace ImGui_ImplOpenGL3 {
    bool Init(const char*) { return true; }
    void Shutdown() {}
    void NewFrame() {}
    void RenderDrawData(void*) {}
}
