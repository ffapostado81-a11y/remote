// STUB — Replace with real imgui.cpp from https://github.com/ocornut/imgui
#include "imgui.h"
#include <cstdarg>

static ImGuiContext g_ctx;
static ImGuiIO g_io;
static ImDrawData g_dd;

namespace ImGui {
    ImGuiContext* CreateContext() { return &g_ctx; }
    void DestroyContext(ImGuiContext*) {}
    void StyleColorsDark() {}
    ImGuiIO& GetIO() { return g_io; }
    void NewFrame() {}
    void Render() {}
    void EndFrame() {}
    ImDrawData* GetDrawData() { return &g_dd; }
    bool Begin(const char*, bool*, int) { return true; }
    void End() {}
    bool Checkbox(const char*, bool*) { return false; }
    bool SliderFloat(const char*, float*, float, float, const char*, int) { return false; }
    bool SliderInt(const char*, int*, int, int, const char*, int) { return false; }
    void Text(const char* fmt, ...) { (void)fmt; }
    void Separator() {}
    void SameLine(float, float) {}
    bool CollapsingHeader(const char*, int) { return true; }
    bool RadioButton(const char*, int*, int) { return false; }
    void SetNextWindowSize(float, float, int) {}
    void SetNextWindowPos(float, float, int, float, float) {}
}
